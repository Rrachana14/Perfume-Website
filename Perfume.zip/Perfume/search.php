<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['searchTerm'])) {
    $searchTerm = $conn->real_escape_string($_POST['searchTerm']);
    
    // Query to search for products
    $sql = "SELECT product_name, product_url FROM products WHERE product_name LIKE '%$searchTerm%' LIMIT 10";
    $result = $conn->query($sql);
    
    $suggestions = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $suggestions[] = [
                'label' => $row['product_name'], // Displayed in the autocomplete suggestions
                'url' => $row['product_url']    // URL of the selected product
            ];
        }
    }
    
    // Return the suggestions as a JSON response
    echo json_encode($suggestions);
}

$conn->close();
?>
