// Function to play sound effect
function playSound() {
    var audio = new Audio('sound_effect.mp3'); // Replace 'sound_effect.mp3' with your sound file path
    audio.play();
}
