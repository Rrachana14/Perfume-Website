<?php
// Start session
session_start();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Get user ID from session
        $userId = $_SESSION['user_id'];

        // Get product ID and quantity from POST data
        $productId = $_POST['productId'];
        $quantity = $_POST['quantity'];

        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ecommerce";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement to check if the product already exists in the cart
        $stmt_check = $conn->prepare("SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?");
        $stmt_check->bind_param("ii", $userId, $productId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        // Check if the product already exists
        if ($result_check->num_rows > 0) {
            // Product already exists in the cart
            http_response_code(400); // Bad Request
            echo "Product already exists in the cart!";
            exit();
        } else {
            // Product does not exist in the cart, proceed with insertion
            // Prepare SQL statement to insert into cart_items table
            $stmt_insert = $conn->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("iii", $userId, $productId, $quantity);
            $stmt_insert->execute();

            // Close statements
            $stmt_insert->close();
        }

        // Close connection
        $stmt_check->close();
        $conn->close();
    } else {
        // User is not logged in
        http_response_code(401); // Unauthorized
        header("Location: login.php");
        exit(); // Stop further execution
    }
} else {
    // Invalid request method
    http_response_code(405); // Method Not Allowed
    echo "Invalid request method";
    exit(); // Stop further execution
}
