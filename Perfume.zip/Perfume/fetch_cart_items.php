<?php
session_start();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Get user ID from session
        $userId = $_SESSION['user_id'];

        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ecommerce";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement to fetch cart items with product details
        $sql = "SELECT ci.quantity,p.prod_price, p.image_url, p.prod_description, p.prod_name ,p.product_id
                FROM cart_items ci
                INNER JOIN products p ON ci.product_id = p.product_id
                WHERE ci.user_id = ?";

        // Prepare and bind parameterized query
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);

        // Execute query
        $stmt->execute();

        // Get result
        $result = $stmt->get_result();

        // Create an array to store cart items with product details
        $cartItems = [];

        // Fetch each row and store in array
        while ($row = $result->fetch_assoc()) {
            $cartItems[] = $row;
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();

        // Send response as JSON
        header('Content-Type: application/json');
        echo json_encode($cartItems);
        exit(); // Stop further execution
    } else {
        // User is not logged in
        http_response_code(401); // Unauthorized
        exit(); // Stop further execution
    }
} else {
    // Invalid request method
    http_response_code(405); // Method Not Allowed
    echo "Invalid request method";
    exit(); // Stop further execution
}
?>
