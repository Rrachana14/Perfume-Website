<?php
// Start session
session_start();

?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Shop page</title>
  <link rel="stylesheet" href="nav.css">
  <link rel="stylesheet" href="productCard.css">
  <link rel="stylesheet" href="footer.css">

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />

  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script>
    $(document).ready(function() {
      // Your code for the "rlogo" hover effect
      $(".rlogo").hover(
        function() {
          $(this).find("h5").css({
            top: "calc(100% + 10px)",
            opacity: "1",
            transform: "translate(-50%, -10px)"
          });
        },
        function() {
          $(this).find("h5").css({
            top: "110%",
            opacity: "0",
            transform: "translate(-50%, 130%)"
          });
        }
      );

      // Your code for the "perf" and "perfume" hover effect
      $("#perf").mouseenter(function() {
        $("#perfume").slideDown("slow");
      });

      $("#perf").mouseleave(function() {
        $("#perfume").slideUp("slow");
      });

      $("#perfume").mouseenter(function() {
        $("#perfume").slideDown("slow");
      });

      $("#perfume").mouseleave(function() {
        $("#perfume").slideUp("slow");
      });

      // Your code for the "signin" click and mouseleave effect
      $("#signin").click(function() {
        $(".signin").slideToggle("slow");
      });

      $(".signin").mouseleave(function() {
        $(".signin").slideUp("slow");
      });
    });



    // $(document).ready(function () {
    //   $.ajax({
    //     url: 'fetch_products.php',
    //     type: 'GET',
    //     dataType: 'json',
    //     success: function (products) {
    //       // Call a function to display products using the retrieved data
    //       toDisplayProduct(products);
    //     },
    //     error: function (xhr, status, error) {
    //       console.error('Error fetching product data:', error);
    //     }
    //   });
    // });
  </script>
</head>
<style>
  * {
    margin: 0;
    padding: 0;
  }

  body {
    width: 100%;
    min-height: 100vh;
    background-color: #e2e2e2;
  }

  /* MAIN */
  .main {
    width: 100%;
    min-height: 100vh;
    display: flex;
    margin-top: 20px;
    background-color: #fff3f5;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .left-bar {
    width: 24%;
    padding: 0px 10px;
    margin: 10px;
    background-color: #ffacc8;
    height: 80vh;
  }

  .type {
    margin: 30px 6px;
  }

  .type h6 {
    font-size: 32px;
    font-weight: 700;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    border-bottom: 2px solid #666;
    color: #666;
    margin-bottom: 10px;
  }

  .flex-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .stock-btn button {
    padding: 3px 7px;
    border-radius: 3px;
    background-color: grey;
    border: none;
    color: white;
  }

  .stock-btn .btn-active {
    border: 1px solid #8b88bc;
    color: black;
    background-color: white;
    transition: all ease-in-out 0.2s;
  }

  .flex-box input[type="number"] {
    -moz-appearance: textfield;
    appearance: textfield;
    width: 25%;
    padding: 4px 8px;
    margin: 14px 0;
  }

  input[type="number"]:focus {
    outline: none;
  }

  input[type="number"]::-webkit-inner-spin-button,
  input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
  }

  /* CUSTOMIZE RANGE INPUT */
  input[type="range"] {
    -webkit-appearance: none;
    width: 100%;
    height: 10px;
    border-radius: 5px;
    background: #d3d3d3;
    outline: none;
    margin: 10px 0;
  }

  /* TRACK */
  input[type="range"]::-webkit-slider-runnable-track {
    width: 100%;
    height: 10px;
    border-radius: 5px;
    background: #6cb1e5
  }

  /* THUMB SLIDER */
  input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #ffffff;
    /* White thumb */
    border: 2px solid #666;
    cursor: pointer;
    margin-top: -5px;
  }

  input[type="range"]::-moz-range-thumb {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #ffffff;
    border: 1px solid #666666;
    cursor: pointer;
    margin-top: -5px
  }

  input[type="checkbox"] {
    display: none;

  }

  label {
    display: inline-block;
    cursor: pointer;
  }

  label:before {
    content: '';
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 2px solid #9ab8db;
    background-color: #fff;
    margin-right: 15px;
  }

  input[type="checkbox"]:checked+label:before {
    background-color: #666;

  }

  input[type="checkbox"]:checked+label:before {
    content: '\2713';
    font-size: 14px;
    color: #fff;
    text-align: center;
    line-height: 20px;
  }

  .multipleChosen {
    width: 300px;
    /* margin-top: 10px */
  }


  /* PRODUCT CONTAINER */
  .product-container {
    width: 80%;
    min-height: 100vh;
    display: flex;
    flex-wrap: wrap;

  }

  /* ALERT  */
  .alert-success {
    display: none;
    position: fixed;
    text-align: center;
    align-items: center;
    top: 80px;
    left: 10px;
    z-index: 99;
    /* opacity: 0; */
    transition: all 0.5s ease-in-out;
    /* Change transition property */
    /* animation: pop  0.5s  ease-in-out; */
    animation-name: pop;
    animation: pop 0.5s ease;
    background-color: greenyellow;
    padding: 10px 20px;
    border-radius: 5px;
  }

  .alert-success a {
    font-size: 22px;
    margin-left: 10px;
    text-decoration: none;
    font-size: 16px;
    color: black;
  }

  .alert-success.show {
    display: flex;
    /* Show the alert */
    opacity: 1;
  }

  @keyframes pop {
    0% {
      transform: scale(0);
    }

    25% {
      transform: scale(0.5);
    }

    50% {
      transform: scale(2);
    }

    75% {
      transform: scale(1.5);
    }

    100% {
      transform: scale(1);
    }
  }

  /* LOGIN POP BOX */
  .login-box h3 {
    font-size: 20px;
    color: white;
  }

  .login-box {
    /* width: 230px; */
    /* height:100px; */
    display: none;
    background: linear-gradient(to bottom, #588157, #344e41);
    padding: 15px 15px;
    border-radius: 10px;
    position: fixed;
    top: 50%;
    left: 40%;
    z-index: 99;
    animation-name: pop;
    transition: all 0.5s ease-in-out;
    animation: pop 0.5s ease;
  }

  .login-box .flex {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 20px;
  }

  .login-box button {
    padding: 10px 15px;
    border: none;
    margin-right: 20px;
    font-weight: 600;
    font-size: 19px;
    background-color: #a3b18a;
    color: white;
    cursor: pointer;
    border-radius: 5px;
  }

  .login-box button:hover {
    background: linear-gradient(to right, #40916c, #a3b18a);
  }

  #overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    /* Semi-transparent grayish overlay */
    z-index: 1000;
    /* Ensure the overlay appears above other content */
    display: none;
    z-index: 90;
  }
</style>
</head>

<body>

  <div class="login-box">
    <h3>YOU ARE NOT LOGGED IN</h3>
    <div class="flex">
      <button id="login-page">Login Now</button>
      <button id="cancel">Cancel</button>
    </div>
  </div>
  <div id="overlay"></div>
  <!-- NAV -->
  <nav>
    <img class="logo" src="./images/logo.png" />
    <ul class="slide">
      <li><a href="index.php">Home</a></li>
      <li class="flip " id="perf"><a href="shop.php" class="active">Perfume</a></li>
      <table class="menu" id="perfume">
        <tr>
          <th>Perfume</th>
          <th>Combo</th>
          <th>Gifts</th>
        </tr>
        <tr>
          <td><a href="#">Best Seller</a></td>
          <td><a>New Combo</a></td>
          <td><a>Gift Sets</a></td>
        </tr>
        <tr>
          <td><a href="#">Regular Perfume</a></td>
          <td><a>Festival Special Combo</a></td>
        </tr>
        <tr>
          <td><a href="#">Permium Perfume</a></td>
          <td><a>Best Deals</a></td>
        </tr>
        <tr>
          <td><a href="#">Contact</a></td>
        </tr>
      </table>
      <li><a href="deodrant.php">Deodrant</a></li>
      <li><a>Body Mist</a></li>
      <li><a>Attar</a></li>
    </ul>
    <div class="nav-search">
      <input type="text" placeholder="Enter here" />
      <img src="./images/search-4-svgrepo-com.svg" />
    </div>
    <div class="right">
      <div class="rlogo" id="signin">
        <img src="./images/profile-svgrepo-com - Copy.svg" />
        <h5>Profile</h5>
        <div class="signin">
          <div class="logged">
            <?php
            // session_start();
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "ecommerce";

              // Create connection
              $conn = new mysqli($servername, $username, $password, $dbname);

              // Check connection
              if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
              }

              // Retrieve user data from the database based on their email
              $email = $_SESSION['email']; // Assuming 'email' is the session variable containing the user's email
              $sql = "SELECT * FROM users WHERE user_email='$email'";
              $result = $conn->query($sql);

              if ($result->num_rows > 0) {
                // User data found, display or use it as needed
                $userData = $result->fetch_assoc();
                // Example: Display the user's name
                echo '<h4>Welcome,' . $userData['user_name'] . '</h4>';
                echo '<div class="signbox">';
                echo '<a href="logout.php">Logout</a>';
                echo '</div>';
              } else {
                // User data not found
                echo 'Welcome to our website!';
              }

              // Close connection
              $conn->close();
            } else {
              // If user is not logged in, display signup and login links
              // echo '<img src="./images/profile-svgrepo-com - Copy.svg" />';
              // echo '<h5>Profile</h5>';

              echo '<div class="signbox">';
              echo '<a href="signup.php">SIGNUP</a>';
              echo '</div>';
              echo '<div class="signbox">';
              echo '<a href="login.php">LOGIN</a>';
              echo '</div>';
            }
            ?>
          </div>
          <div class="logged">
            <ul>
              <li><a href="">Orders</a></li>
              <li><a href="">Wishlist</a></li>
              <li><a href="">Gift Cards</a></li>
              <li><a href="">Contact Us</a></li>
            </ul>
          </div>
          <div class="logged">
            <ul>
              <li><a href="">Coupons</a></li>
              <li><a href="">Saved</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="rlogo" id="rlogo">
        <img src="./images/heart-svgrepo-com.svg" id="whishlistbtn" />
        <a href="#">
          <h5>Wishlist</h5>
        </a>
      </div>
      <div class="rlogo" id="rlogo">
        <img src="./images/bag-shopping-svgrepo-com - Copy.svg" id="cartbtn" />
        <a href="calculator.php">
          <h5>Cart</h5>
        </a>
      </div>
    </div>
  </nav>
  <!-- PRODUCT CONTAINER -->
  <div class="main">
    <div class="alert alert-success alert-dismissible">
      <h6><strong>Heyy!</strong> Item succesfully added in the cart.</h6>
      <!-- <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> -->
    </div>
    <div class="left-bar">
      <div class="type">
        <div class="flex-box">
          <h6>Out Of Stock</h6>
          <div class="stock-btn">
            <button class="btn-active">Show</button>
            <button>Hide</button>
          </div>
        </div>
      </div>
      <div class="type">
        <h6>Price</h6>
        <div class="flex-box">
          <input type="number" class="num" id="min-price" placeholder="₹0">
          <input type="number" class="num" id="max-price" placeholder="₹5000">
        </div>
        <input type="range" id="price-range" name="price-range" min="0" max="100" value="50">
      </div>

      <div class="type">
        <h6>Brand</h6>
        <div class="flex" id="checkbox">
          <input type="checkbox" id="Carlton London" name="Carlton London"><label for="Carlton London">Carlton London</label>
        </div>
        <div class="flex">
          <input type="checkbox" id="PERFUME LOUNGE" name="PERFUME LOUNGE"><label for="PERFUME LOUNGE">PERFUME LOUNGE</label>
        </div>
        <div class="flex">
          <input type="checkbox" id="DJOKR" name="DJOKR"><label for="DJOKR">DJOKR</label>
        </div>
        <div class="flex">
          <input type="checkbox" id="Burberry" name="Burberry"><label for="Burberry">Burberry</label>
        </div>
        <div class="flex">
          <input type="checkbox" id="Bella-Vita" name="Bella Vita"><label for="Bella-Vita">Bella Vita</label>
        </div>
        <div class="flex">
          <input type="checkbox" id="HVNLY" name="HVNLY"><label for="HVNLY">HVNLY</label>
        </div>
      </div>

    </div>
    <div class="product-container">
      <!-- <div class="product" data-index="1">
        <div class="wish"><i class="fa-solid fa-heart"></i></div>
        <img src="./images/product1.webp" />
        <h4 id="tag">DJOKR</h4>
        <p>Djokr On The Rocks Perfume For Men 100 ml</p>
        <div class="prod-flex">
          <h5 class="price">₹100</h5>
          <button class="addCart">ADD TO CART</button>
        </div>
      </div>
      <div class="product" data-index="2">
        <div class="wish"><i class="fa-solid fa-heart"></i></div>
        <img src="./images/product2.webp" />
        <h4 id="tag">Carlton London</h4>
        <p>Women Edition Blush Eau de Parfum- 100 ml</p>
        <div class="prod-flex">
          <h5 class="price">₹100</h5>
          <button class="addCart">ADD TO CART</button>
        </div>
      </div> -->

    </div>
  </div>
  <footer>
    <div class="footer-inner">
      <div class="footer-column">
        <img class="logo" src="./images/logo.png" />
        <br>
        <br>
        <h3><i>YOUR GATEWAY TO A WORLD OF CAPTIVATING AROMAS!</i></h3>

      </div>
      <div class="footer-column">
        <h2>Locate Us</h2>
        <p>
          <br>
          Fragrance Heaven Pvt Ltd,<br />
          A-142,Phase 1,MIDC,<br />
          Kalyan, Dt.Thane<br />
          Pin: 421306,Maharashtra,India<br />
        </p>
      </div>
      <div class="footer-column">
        <h2>Contact Us </h2>
        <p>
          <br>
          Email: fragranceheaven@gmail.com<br />
          Phone: 123-456-7890<br />

          <br>
        <h2 style="color:black;"> <a href="aboutuspic.html" style="color: black; text-decoration: none;">About Us</a> </h2>
        </p>
      </div>
      <div class="footer-column">
        <h2>Quick Links</h2> <br>

        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="#">Perfume</a></li>
          <li><a href="deodrant.php">Deodorant</a></li>
        </ul>
      </div>
      <div class="footer-column">
        <h2 style="color:white;"> Quick Links</h2> <br>
        <ul>
          <li><a >Body Mist</a></li>
          <li><a >Attar</a></li>
          <li><a href="form3.html">Student Discount</a></li>
        </ul>

      </div>

    </div>
    <div class="footer-bottom">
      <p>&copy; 2024, Fragrance Heaven . All Rights Reserved.</p>
    </div>
  </footer>
  <script src="nav.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script>
    const productContainer = document.querySelector('.product-container');
    let products
    //         const products = [
    //     {
    //         title: 'Carlton London',
    //         description: 'Carlton London On The Rocks Perfume For Men 100 ml',

    //         price: 400,
    //         image: './images/product1.webp'
    //     },
    //     {
    //         title: 'DJOKR',
    //         description: 'Description for DJOKR product',
    //         price: 350,
    //         image: './images/product2.webp'
    //     },
    //     {
    //         title: 'Burberry',
    //         description: 'Description for Burberry product',
    //         price: 3200,
    //         image: './images/product3.webp'
    //     },
    //     {
    //         title: 'DJOKR',
    //         description: 'Description for DJOKR product',
    //         price: 959,
    //         image: './images/product4.webp'
    //     },
    //     {
    //         title: 'HVNLY',
    //         description: 'Description for HVNLY product',
    //         price: 499,
    //         image: './images/product5.webp'
    //     },
    //     {
    //         title: 'PERFUME LOUNGE',
    //         description: 'Description for PERFUME LOUNGE product',
    //         price: 1249,
    //         image: './images/product6.webp'
    //     },
    //     {
    //         title: 'Carlton London',
    //         description: 'Description for Bella Vita product',
    //         price: 2000,
    //         image: './images/product7.webp'
    //     },
    //     {
    //         title: 'Bella Vita',
    //         description: 'Spiced Amber Vegan Eau De Toilette - 100 ml',
    //         price: 648,
    //         image: './images/product8.webp'
    //     },
    //     {
    //         title: 'Burberry',
    //         description: 'Spiced Amber Vegan Eau De Toilette - 100 ml',
    //         price: 648,
    //         image: './images/product9.webp'
    //     }

    // ];



    //FUNCTION TO DISPLAY PRODUCTS 

    const toDisplayProduct = (products) => {
      productContainer.innerHTML = "";
      products.forEach((product, index) => {

        const productElement = document.createElement('div');
        productElement.classList.add('product');

        const wishBox = document.createElement('div');
        wishBox.classList.add('wish');
        wishBox.innerHTML = `<i class="fa-solid fa-heart"></i>`;

        const productImage = document.createElement('img');
        productImage.src = product.image_url;
        const productTitle = document.createElement('h4');
        productTitle.setAttribute('id', 'tag');
        productTitle.innerHTML = product.prod_name;
        const productDescription = document.createElement('p');
        productDescription.innerHTML = product.prod_description;

        const flexBox = document.createElement('div');
        flexBox.classList.add('prod-flex');
        const productPrice = document.createElement('h5');
        productPrice.classList.add('price');
        productPrice.innerHTML = "₹" + product.prod_price;
        const cartBtn = document.createElement('button');
        cartBtn.classList.add('addCart');
        cartBtn.innerHTML = 'ADD TO CART';


        flexBox.appendChild(productPrice);
        flexBox.appendChild(cartBtn);


        const ratingElement = document.createElement('div');
        ratingElement.classList.add('rating');
        const ratingValue = Math.floor(Math.random() * 3) + 3; // Generate random rating from 1 to 5
        const stars = '★'.repeat(ratingValue) + '☆'.repeat(5 - ratingValue); // Create stars based on rating
        ratingElement.innerHTML = `${stars}`;

        productElement.appendChild(wishBox);
        productElement.appendChild(productImage);
        productElement.appendChild(productTitle);
        productElement.appendChild(productDescription);
        productElement.appendChild(flexBox)
        productElement.appendChild(ratingElement);
        productElement.dataset.index = product.product_id;
        productContainer.appendChild(productElement)


        console.log(productElement)
      });
    }


    document.addEventListener("DOMContentLoaded", async () => {
      try {
        const response = await fetch('fetch_products.php');
        if (!response.ok) {
          throw new Error('Failed to fetch product data');
        }
        products = await response.json();
        toDisplayProduct(products);
        // Add event listener for product images
        document.querySelectorAll('.product img').forEach(prodImg => {
          prodImg.addEventListener('click', (e) => {
            const prodIndex = e.target.closest('.product').dataset.index;
            const prodTitle = e.target.closest('.product').querySelector('h4').innerHTML;
            const prodDescription = e.target.closest('.product').querySelector('p').innerHTML;
            const prodPrice = e.target.closest('.product').querySelector('.price').innerHTML;
            const url = `product.php?id=${prodIndex}`;
            window.location.href = url;
          });
        });


        console.log("The products are ", products)
        // FUNCTION TO ADD PRODUCT IN THE CART
        // function addToCart(productId, productName, productDesp, productPrice) {

        //   const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
        //   let productExist = false;
        //   cartItems.forEach(item => {
        //     if (item.productId === productId) {
        //       productExist = true;
        //     }
        //   });
        //   if (!productExist) {
        //     cartItems.push({
        //       productId,
        //       productName,
        //       productDesp,
        //       productPrice,
        //       productQuantity: 1
        //     });
        //     // confirm("product add")
        //     document.querySelector('.alert-success').classList.add('show');
        //     setTimeout(function() {
        //       document.querySelector('.alert-success').classList.remove('show');
        //     }, 3000)

        //   }
        //   localStorage.setItem("cartItems", JSON.stringify(cartItems));


        // }


        $(document).ready(function() {
          $('.addCart').click(function() {
            // Get product ID, quantity, and user ID
            var productContainer = $(this).closest('.product');
            var quantityElement = productContainer.find('.prod-flex .quantity');
            var quantity = quantityElement.length ? quantityElement.text().trim() : 1;
            console.log('Quantity:', quantity);
            // const prodQauntity = quantityElement ? quantityElement.innerHTML : 1;
            var productId = $(this).closest('.product').data('index');


            // var quantity = 1; // You can change this to get the actual quantity from the user interface

            <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) { ?>
              var userId = <?php echo $_SESSION['user_id']; ?>;
            <?php } else { ?>
              // Perform a specific action if userId is null or empty
              // For example, redirect the user to the login page
              // window.location.href = 'login.php';
              document.querySelector('.login-box').style.display = 'block';
              document.querySelector('#overlay').style.display = 'block';
            <?php } ?>

            // Send AJAX request to add product to cart
            $.ajax({
              url: 'addtocart.php',
              method: 'POST',
              data: {
                productId: productId,
                quantity: quantity,
                userId: userId
              },
              success: function(response) {
                // Handle success response
                // Check if response contains an error message
                if (response.startsWith("Error")) {
                  // Product already exists in the cart
                  alert(response);
                } else {
                  // Product added to cart successfully
                  document.querySelector(".alert-success").classList.add("show");
                  setTimeout(function() {
                    document.querySelector(".alert-success").classList.remove("show");
                  }, 3000);
                }
              },
              error: function(xhr, status, error) {
                // Handle error
                if (xhr.status === 401) {
                  // Redirect to login page
                  document.querySelector('.login-box').style.display = 'block';
                  document.querySelector('#overlay').style.display = 'block';
                } else {
                  console.error('Error adding product to cart:', error);
                  // Handle other errors
                }
              }
            });
          });
        });




        document.querySelector('#login-page').addEventListener('click', () => {
          window.location.href = 'login.php';
        })

        document.querySelector('#cancel').addEventListener('click', () => {
          document.querySelector('.login-box').style.display = 'none';
          document.querySelector('#overlay').style.display = 'none';

        })

        // document.querySelector('.product-container').addEventListener('click', function(event) {
        //   if (event.target && event.target.classList.contains('addCart')) {
        //     // console.log(event)
        //     const cartBtn = event.target;
        //     const prodFlex = cartBtn.parentNode;
        //     const productContainer = prodFlex.parentNode;
        //     // console.log(cartBtn)
        //     const index = productContainer.dataset.index;
        //     const prodTitle = productContainer.querySelector('h4').innerHTML;
        //     const prodDescription = productContainer.querySelector('p').innerHTML;
        //     const prodPrice = productContainer.querySelector('.price').innerHTML
        //     // console.log(productContainer.querySelector('h4').innerHTML);
        //     // console.log(productContainer.querySelector('p').innerHTML)
        //     // console.log(productContainer.querySelector('.price').innerHTML);
        //     const quantityElement = productContainer.querySelector('.qaunti');
        //     const prodQauntity = quantityElement ? quantityElement.innerHTML : 1;
        //     // console.log(index);

        //     addToCart(index, prodTitle, prodDescription, prodPrice);
        //     // });
        //   }
        // });



        // EVENLISTNER ON WISH-HEART
        document.querySelectorAll('.product').forEach((product) => {
          product.addEventListener('mouseenter', (e) => {

            // console.log(e.currentTarget.parentNode);
            const wish = e.currentTarget;
            heart = wish.querySelector('.wish i');
            heart.style.transform = 'scale(1)';
            // });
            product.addEventListener('mouseleave', (e) => {
              const wish = e.currentTarget;
              heart = wish.querySelector('.wish i');
              heart.style.transform = ' scale(0)';
            });
          })
        });
        document.querySelectorAll('.wish i').forEach((heart) => {
          heart.addEventListener('click', (e) => {
            e.preventDefault();
            if (heart.style.color == "white") {
              heart.style.color = "red";
            } else {
              heart.style.color = "white";
            }
          })
        })

        //STOCK BUTTON ADDING ACTIVE CLASS
        document.querySelectorAll('.stock-btn button').forEach(button => {
          button.addEventListener('click', (e) => {
            const elem = e.currentTarget;
            document.querySelectorAll('.stock-btn button').forEach(button => {
              button.classList.remove('btn-active');
            });
            elem.classList.add('btn-active');

          })
        })

        // SORING BASED ON THE PRICE AND BRAND
        const filterProductByPrice = () => {
          const selectedBrands = Array.from(document.querySelectorAll('input[type="checkbox"]:checked')).map(checkbox => checkbox.getAttribute('name'));
          let minPrice = parseFloat(document.querySelector('#min-price').value);
          let maxPrice = parseFloat(document.querySelector('#max-price').value);

          const filteredProducts = products.filter(product => {
            const productPriceString = String(product.prod_price);
            const productPrice = parseFloat(productPriceString.replace('₹', ''));

            const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(product.prod_name); //
            const priceMatch = isNaN(minPrice) || isNaN(maxPrice) || (productPrice >= minPrice && productPrice <= maxPrice);

            return brandMatch && priceMatch;

          });
          toDisplayProduct(filteredProducts)

        }
        document.querySelector('#min-price').addEventListener('input', filterProductByPrice);
        document.querySelector('#max-price').addEventListener('input', filterProductByPrice);
        // localStorage.clear()


        document.querySelectorAll('input[type="checkbox"]').forEach((checkbox, index) => {
          checkbox.addEventListener('click', () => {
            filterProductByPrice();
          });
        });
      } catch (error) {
        console.error('Error fetching product data:', error);
      }
    });
  </script>
</body>

</html>