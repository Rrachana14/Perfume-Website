<?php
// Start session
session_start();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Get user ID from session
        $userId = $_SESSION['user_id'];
        
        // Get product ID and quantity from POST data
        $productId = $_POST['productId'];
        // $quantity = $_POST['quantity'];
        
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ecommerce";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        // Prepare SQL statement to check if the product already exists in the cart
        $stmt_check = $conn->prepare("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?");
        $stmt_check->bind_param("ii", $userId, $productId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        
        
        
        // Close connection
        $stmt_check->close();
        $conn->close();
    } 
} else {
    // Invalid request method
    // http_response_code(400);
    http_response_code(405); // Method Not Allowed
    echo "Invalid request method";
    exit(); // Stop further execution
}
?>
