<?php
// Start the session before any output
session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fragnance Heaven</title>
  <link rel="shortcut icon" href="./images/favicon.png" type="image/x-icon" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
  integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
  crossorigin="anonymous" referrerpolicy="no-referrer" />
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />
  <!-- <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->
  <link rel="stylesheet" href="footer.css">
  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" href="nav.css" >
  <script>
  
  // Wrap all your jQuery code inside $(document).ready() to ensure it executes after the DOM is fully loaded
  
  $(document).ready(function() {
  // Your code for the "rlogo" hover effect
  $(".rlogo").hover(
    function() {
      $(this).find("h5").css({
        top: "calc(100% + 10px)",
        opacity: "1",
        transform: "translate(-50%, -10px)"
      });
    },
    function() {
      $(this).find("h5").css({
        top: "110%",
        opacity: "0",
        transform: "translate(-50%, 130%)"
      });
    }
  );

  // Your code for the "perf" and "perfume" hover effect

  $("#perf").mouseenter(function() {
    $("#perfume").slideDown("slow");
  });

  $("#perf").mouseleave(function() {
    $("#perfume").slideUp("fast");
  });

  $("#perfume").mouseenter(function() {
    $("#perfume").slideDown("slow");
  });

  $("#perfume").mouseleave(function() {
    $("#perfume").slideUp("slow");
  });

  // Your code for the "signin" click and mouseleave effect
  $("#signin").click(function() {
    $(".signin").slideToggle("slow");
  });

  $(".signin").mouseleave(function() {
    $(".signin").slideUp("slow");
  });

  // Your code for the "card" scaling effect
  $(".card").hover(
    function() {
      $(this).css({
        transform: "scale(1.1)",
        transition: "transform 0.5s"
      });
    },
    function() {
      $(this).css("transform", "scale(1)");
    }
  );

  // Your code for the image slider
  var currentIndex = 0;
  var images = $("header img");
  var totalImages = images.length;

  $(images[currentIndex]).show();

  function showNextImage() {
    $(images[currentIndex]).fadeOut("slow", function() {
      currentIndex = (currentIndex + 1) % totalImages;
      $(images[currentIndex]).fadeIn("slow");
    });
  }

  var interval = setInterval(showNextImage, 8000);

  $(".explore").hover(function() {
    clearInterval(interval);
  }, function() {
    interval = setInterval(showNextImage, 8000);
  });
});

  </script>
  
</head>
<style>
  * {
    margin: 0;
    padding: 0;
  }

  body {
    width: 100%;
    min-height: 100vh;
    background-color: #fff3f5;
   
  }
  /* HEADER */
  .main-header {
    width: 100%;
    height: 30vw;
    min-height: 250px;
    position: relative;
   
  }

  header img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: none;
  }

  .explore {
    padding: 1rem 3rem;
    font-weight: 600;
    font-size: 21px;
    background-color:#ff99bb;
    border-radius: 30px;
    color: white;
    position: absolute;
    bottom: 10%;
    left: 10%;
    cursor: pointer;
    border: 2px solid white; /* Add border with white color */

  }

  .explore:hover {
    background-color: white;
    color:#ff99bb;
    box-shadow: 2px 1px 4px rgb(40, 40, 40);
    font-weight: 800;
  }

  /* SECONDARY NAVIGATION FOR STUDENT DISCOUNT */
   
  .secondary-header {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fff3f5; /* Dark background color */
    font-weight: bold;
    color: #ff66a3; /* White text color */
    padding:10px 0; /* Add some padding */
    text-align: center; /* Center align text */


   }

   .secondary-header p {
     font-size: 20px; /* Increase font size */
    
   }

   .secondary-header button {
     background-color: #ff66a3;; /* Button background color */
     color: white; /* Button text color */
     border: none; /* Remove button border */
     padding: 10px 20px; /* Add padding */
     font-size: 16px; /* Button font size */
     cursor: pointer; /* Change cursor on hover */
     transition: background-color 0.3s; /* Smooth transition */
   }

   .secondary-header button:hover {
     background-color: #ff99bb; /* Darker background color on hover */
   }

/* Pulsating animation */
   @keyframes pulsate {
       0% {
           transform: scale(1);
       }
       100% {
           transform: scale(1.1);
       }
   }
   .pulsating {
     animation: pulsate 1.5s infinite alternate;
     
   }
  
  
/* CARD CONTAINER */
  .card-content {
    width: 100%;
    min-height: 55vh;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-evenly;
    margin: 40px 0;
  }

  .card {
    width: 220px;
    height: 310px;
    background-color: #ffffff;
    padding: 8px;
    border: 1px solid #6a6868;
    box-shadow: 2px 2px 5px 1px rgb(182, 155, 155);
    transition: all ease-in-out 0.5s;
    cursor: pointer;
    margin: 12px 0;
  }

  .card h3 {
    font-size: 20px;
    text-align: center;
    margin-top: 15px;
    color: black;
  }

  .card img {
    width: 210px;
    height: 265px;
    margin: 0 auto;
  }

  .card h3,
  .card p {
    margin-bottom: 8px;
  }

  .card img {
    width: 210px;
    display: block;
    margin: 0 auto;
    box-shadow: 2px 2px 5px 1px rgba(182, 155, 155);
  }

 

  

  /* REPONSIVE  */
  

</style>

<body>
  <nav>
    <a href="index.php"><img class="logo" src="./images/logo.png" /> </a>
    <ul class="slide">
      <li><a href="index.php" class="active">Home</a></li>
      <li class="flip " id="perf"><a href="shop.php">Perfume</a></li>
      <table class="menu" id="perfume">
        <tr>
          <th>Perfume</th>
          <th>Combo</th>
          <th>Gifts</th>
        </tr>
        <tr>
          <td><a href="#">Best Seller</a></td>
          <td><a>New Combo</a></td>
          <td><a>Gift Sets</a></td>
        </tr>
        <tr>
          <td><a href="#">Regular Perfume</a></td>
          <td><a>Festival Special Combo</a></td>
        </tr>
        <tr>
          <td><a href="#">Permium Perfume</a></td>
          <td><a>Best Deals</a></td>
        </tr>
        <tr>
          <td><a href="#">Contact</a></td>
        </tr>
      </table>
      <li><a href="deodrant.php">Deodrant</a></li>
      <li><a>Body Mist</a></li>
      <li><a>Attar</a></li>
    </ul>
    <div class="nav-search">
  <input id="search-bar" type="text" placeholder="Search for Perfume, Deo, etc..." />
  <img src="./images/search-4-svgrepo-com.svg" />
</div>

    <div class="right">
      <div class="rlogo" id="signin">
        <img src="./images/profile-svgrepo-com - Copy.svg" />
        <h5>Profile</h5>
        <div class="signin">
          <div class="logged">
          <?php
        // session_start();
        if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "ecommerce";
      
          // Create connection
          $conn = new mysqli($servername, $username, $password, $dbname);
      
          // Check connection
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }
      
          // Retrieve user data from the database based on their email
          $email = $_SESSION['email']; // Assuming 'email' is the session variable containing the user's email
          $sql = "SELECT * FROM users WHERE user_email='$email'";
          $result = $conn->query($sql);
      
          if ($result->num_rows > 0) {
              // User data found, display or use it as needed
              $userData = $result->fetch_assoc();
              // Example: Display the user's name
              echo '<h4>Welcome,' . $userData['user_name'] . '</h4>';
              echo '<div class="signbox">';
              echo '<a href="logout.php">Logout</a>';
              echo '</div>';
          } else {
              // User data not found
              echo 'Welcome to our website!';
          }
      
          // Close connection
          $conn->close();
        } else {
            // If user is not logged in, display signup and login links
            // echo '<img src="./images/profile-svgrepo-com - Copy.svg" />';
            // echo '<h5>Profile</h5>';
            
            echo '<div class="signbox">';
            echo '<a href="signup.php">SIGNUP</a>';
            echo '</div>';
            echo '<div class="signbox">';
            echo '<a href="login.php">LOGIN</a>';
            echo '</div>';
            
        }
        ?>
          </div>
          <div class="logged">
            <ul>
              <li><a href="">Orders</a></li>
              <li><a href="">Wishlist</a></li>
              <li><a href="">Gift Cards</a></li>
              <li><a href="">Contact Us</a></li>
            </ul>
          </div>
          <div class="logged">
            <ul>
              <li><a href="">Coupons</a></li>
              <li><a href="">Saved</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="rlogo" id="rlogo">
        <img src="./images/heart-svgrepo-com.svg" id="whishlistbtn" />
        <a href="#">
          <h5>Wishlist</h5>
        </a>
      </div>
      <div class="rlogo" id="rlogo">
        <img src="./images/bag-shopping-svgrepo-com - Copy.svg" id="cartbtn" />
        <a href="calculator.php">
          <h5>Cart</h5>
        </a>
      </div>
    </div>
  </nav>

  <header>
    <div class="secondary-header ">
     <div class="pulsating"> 
      <p> Want Student Discount? Check your eligibility now!!! <button id="check" >Check Now</button> 
      </p>
     </div>   
 

    <div class="main-header">
     <br>
     <img src="./images/header2.jpg"> <img src="./images/header1.jpeg">
     <img src="./images/header3.webp">
     <a class="explore" href="shop.php" >Explore <i class="fa-solid fa-arrow-right"></i></a>
    </div>
  </header>
   
  <section class="card-content">
      <div class="card" id="perfumes">
        <img src="./images/card1.webp" />
        <h3>Perfume</h3>
      </div>
      <div class="card" id="deo">
        <img src="./images/card2.jpg" />
        <h3>Deodrant</h3>
      </div>

      <div class="card">
        <img src="./images/card3.jpg" />
        <h3>Body Mist</h3>
      </div>
      <div class="card">
        <img src="./images/card4.webp" />
        <h3>Attar</h3>
      </div>
  </section>
  <footer style="color:black background color:white;">
    <div class="footer-inner">
      <div class="footer-column">
        <a href="index.php"><img class="logo" src="./images/logo.png" /> </a>
        <br>
   
        <h3><i>YOUR GATEWAY TO A WORLD OF CAPTIVATING AROMAS!</i></h3>

      </div>
      <div class="footer-column">
        <h2>Locate Us</h2>
        <p>
          <br>
          Fragrance Heaven Pvt Ltd,<br />
          A-142,Phase 1,MIDC,<br />
          Kalyan, Dt.Thane<br />
          Pin: 421306,Maharashtra,India<br />
        </p>
      </div>
      <div class="footer-column">
        <h2>Contact Us </h2>
        <p>
          <br>
          Email: fragranceheaven@gmail.com<br />
          Phone: 123-456-7890<br />

          <br>
        <h2><a href="aboutuspic.html" style="color: black; text-decoration: none;">About Us</a></h2>
        </p>
      </div>
      <div class="footer-column">
        <h2>Quick Links</h2> <br>
      
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="shop.php">Perfume</a></li>
              <li><a href="deodrant.php">Deodorant</a></li>
            </ul>
      </div>
      <div class="footer-column">
        <h2 style="color:white;"> Quick Links</h2> <br>	
            <ul>
              <li><a>Body Mist</a></li>
              <li><a>Attar</a></li>
              <li><a href="form3.html">Student Discount</a></li>
            </ul>
          
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2024, Fragrance Heaven . All Rights Reserved.</p>
    </div>
  </footer>
  
  
  
<!-- Load jQuery first -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Then load jQuery UI -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<!-- Add jQuery UI CSS (optional for styling) -->


  <script>
      document.querySelector('#perfumes').addEventListener('click',()=>{
        window.location.href = "shop.php";
      })

      document.querySelector('#deo').addEventListener('click',()=>{
        window.location.href = "deodrant.php";
      })

     document.addEventListener('DOMContentLoaded', function() {
     var cartButton = document.querySelector('#cartbtn');
      if (cartButton) {
         cartButton.addEventListener('click', function() {
             window.location.href = 'calculator.php';
         });
     } else {
         console.error('Element with ID "cartbtn" not found.');
     }
 });


     document.querySelector('#check').addEventListener('click', () => {
       window.location.href = 'form3.html';
     })
     $(document).ready(function() {
        console.log("jQuery is working!");
    });
     $(document).ready(function() {
  // Autocomplete functionality
  $("#search-bar").autocomplete({
    source: function(request, response) {
      $.ajax({
        url: "search.php",
        method: "POST",
        dataType: "json",
        data: {
          searchTerm: request.term
        },
        success: function(data) {
          response(data);
        }
      });
    },
    minLength: 2,
    select: function(event, ui) {
      window.location.href = ui.item.url; // Redirect to the selected item's URL
    }
  });
});


  </script>
</body>

</html>