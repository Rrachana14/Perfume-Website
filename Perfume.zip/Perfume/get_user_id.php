<?php
// Start session
session_start();

// Check if the user is logged in
if(isset($_SESSION['user_id'])) {
    // Get the user ID from the session
    $user_id = $_SESSION['user_id'];
    echo 'user id'.$user_id.'this ';
    // Return the user ID as JSON
    echo json_encode(array("user_id" => $user_id));
    
} else {
    // If user is not logged in, return an error message
    echo json_encode(array("error" => "User is not logged in"));
}
?>
