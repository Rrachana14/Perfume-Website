<?php
session_start();
error_log("Cart page accessed.");
// $userId = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" <title>
  Shopping Cart</title>
  <style>
    body {
      background-color: rgb(180, 177, 177);
      position: relative;
    }

    #shopMore {
      padding: 10px 20px;
      position: absolute;
      background-color: green;
      color: white;
      font-weight: 700;
      text-align: center;
      font-family: sans-serif;
      border-radius: 10px;
      top: 0px;
      cursor: pointer;
    }

    #shopMore {
      box-shadow: 0px 0px 5px green, 0px 0px 10px green, 0px 0px 15px green, 0px 0px 20px green;
    }

    .flex-box {
      display: flex;
      justify-content: space-between;
    }

    .main {
      width: 90%;
      min-height: 90vh;
      margin: 40px auto;
      box-shadow: 2px 2px 2px #0000;
      background-color: white;
      border: 1px solid rgb(180, 177, 177);
      border-radius: 20px;
      display: flex;
      overflow: hidden;
    }

    .cart {
      width: 70%;
      min-height: 100%;
      padding: 10px 10px;
    }

    .summary {
      width: 30%;
      min-height: 100%;
      background-color: #ffd1dc;
      padding: 10px 10px;
      position: relative;
    }

    h2 {
      font-family: "Gill Sans", "Gill Sans MT", Calibri, "Trebuchet MS",
        sans-serif;
      margin-bottom: 8px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    tr,
    .cart-item {
      /* border: 2px solid black; */
      margin: 20px;
    }

    .cart-item img {
      width: 50%;
      height: 40%;
    }

    th {
      width: 20%;
      color: grey;
      text-transform: uppercase;
      font-size: 19px;
      /* margin: 50px; */
      padding-bottom: 20px;
    }

    td {
      width: 20%;
      padding: 10px;
      text-align: center;
      /* background-color: yellow; */
      position: relative;
      /* border: 1px solid red; */
      /* display: block; */
      /* align-items: center; */
    }

    td img {
      width: 70%;
    }

    td p {
      font-size: 13px;
    }

    td h4 {
      font: 14px;
      font-family: "Lucida Sans", "Lucida Sans Regular", "Lucida Grande",
        "Lucida Sans Unicode", Geneva, Verdana, sans-serif;
    }

    td button {
      border-radius: 50%;
      align-items: center;
      cursor: pointer;
      font-size: 18px;
      border: 1px solid #c8b6ff;
      padding: 5px;
    }

    td button:hover {
      box-shadow: 0px 1px 1px #c8b6ff;
    }

    .delete {
      width: 40px;
      cursor: pointer;
      /* display: none; */
    }


    .delete img {
      width: 20px;
      display: none;
    }

    span {
      margin: 0px 10px;
      font-size: 19px;
    }

    .summary h4 {
      font-size: 19px;
      text-transform: uppercase;
      font-family: monospace;
    }

    .summ-container {
      width: 90%;
      height: 100%;
      margin: auto;
    }

    #shipping,
    input {
      padding: 8px 15px;
      border: none;
    }

    input {
      width: 80%;
    }

    input:focus {
      outline: none;
    }

    input:hover,
    #shipping:hover {
      border: 2px solid #cb98d4;
    }

    #apply {
      padding: 0px 25px;
      margin: 25px 0;
      background-color: #fbf6ef;
      color: black;
      border: none;
      cursor: pointer;
      transition: all ease-in-out 1s;
      position: relative;
      overflow: hidden;
    }

    #apply h3 {
      font-weight: 600;
      font-size: 17px;
      position: relative;
      z-index: 9;
    }

    #apply::after {
      content: "";
      width: 165%;
      height: 100%;
      border-radius: 50px;
      background-color: #735d78;
      position: absolute;
      transition: all ease-in-out 0.6s;
      top: 0;
      left: -165%;
    }

    #apply:hover::after {
      left: -30px;
    }

    #apply:hover h3 {
      color: white;
    }

    #checkout {
      width: 100%;
      cursor: pointer;
      background-color: #a69da8;
      border: none;
      color: white;
      font-size: 16px;
    }

    #checkout:hover {
      background: #735d78;
    }

    #cart {
      margin-top: 20px;
    }

    #cart h2 {
      text-align: center;
    }

    .cart-item {
      list-style-type: none;
      padding: 0;
    }

    .cart-item {
      margin-bottom: 10px;
      padding-bottom: 5px;
    }

    .align-bottom {
      width: 85%;
      position: absolute;
      bottom: 5%;
    }


    .empty-cart {
      font-size: larger;
      color: #cb98d4;
      text-align: center;
    }

    @keyframes pulsate {
        0% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.1);
        }
        100% {
            transform: scale(1);
        }
    }
  </style>
</head>

<body>
  <div id="shopMore"><i class="fa-solid fa-arrow-left"></i>Shop More</div>
  <div class="main">
    <div class="cart">
      <h2>Shopping Cart</h2>
      <hr />
      <table>
        <tr>
          <th>Product</th>
          <th>Details</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Total</th>
          <th class="delete-row"></th>
        </tr>
      </table>
    </div>
    <div class="summary">
      <h2>Summary</h2>
      <hr />
      <div class="summ-container">
        <div class="flex-box">
          <h4 id="item_total">Items - </h4>
          <h4 id="total_amount">$</h4>
        </div>
        <h4>Shipping</h4>
        <select id="shipping">
          <option value="standard">
            Standard Shipping (3-5 business days)
          </option>
          <option value="express">
            Express Shipping (1-2 business days)
          </option>
          <option value="overnight">
            Overnight Shipping (next business day)
          </option>
        </select>
        <h4>Promo code</h4>

        <input type="text" placeholder="Enter the code" name="Pcode" value="" />
        <button id="apply">
          <h3>Apply</h3>
        </button>
        <div class="align-bottom">
          <hr />
          <div class="flex-box">
            <h4>Total Cost</h4>
            <h4 id="final_amount">"₹"</h4>
          </div>
          <button id="checkout">
            <h3>Checkout</h3>
          </button>
        </div>

      </div>
    </div>
  </div>
  <script>
    let decbtns = document.querySelectorAll(".decrement");
    let incbtns = document.querySelectorAll(".increment");
    let totalamount = document.querySelector("#total_amount");
    let itemTotal = document.querySelector("#item_total");
    let finalAmount = document.querySelector("#final_amount");



    //FUNCTION TO DISPLAY PRODUCTS
    const cartElement = document.querySelector(".cart tbody");

    function displayCart(cartItems) {
      if (!Array.isArray(cartItems)) {
    console.error('Invalid cart items format:', cartItems);
    // Handle the error condition appropriately, such as displaying a message to the user
    return;
  }
      if (cartItems.length === 0) {
        const emptyCartMessage = document.createElement("h3");
        emptyCartMessage.classList.add("empty-cart");
        emptyCartMessage.textContent = "You have nothing in the cart.";
        cartElement.appendChild(emptyCartMessage);
      }
      cartItems.forEach(function(item) {
        const row = document.createElement("tr");
        row.classList.add("cart-item");
        row.dataset.productId = item.productId;
        // row.id = `product_${item.product_id}`;
        const productImgCell = document.createElement("td");
        productImgCell.innerHTML = `<img src="${item.image_url}">`;
        // console.log("id", item.productId);
        const descriptionCell = document.createElement("td");
        descriptionCell.textContent = item.prod_description;

        const priceCell = document.createElement("td");
        priceCell.textContent = item.prod_price;
        priceCell.classList.add("price");

        const quantityCell = document.createElement("td");
        quantityCell.innerHTML = `
                    <button class="decrement" data-product-index="${item}">-</button>
                    <span class="quantity">${item.quantity}</span>
                    <button class="increment" data-product-index="${item}">+</button>
                `;
        const totalCell = document.createElement("td");
        totalCell.classList.add("total");
        totalCell.textContent = "₹" + (item.quantity * item.prod_price);
        console.log("QUANTITY AND PRICE", item.quantity + " " + item.prod_price);
        const deleteCell = document.createElement('td'); // Create a new table cell for the delete button
        deleteCell.classList.add('delete'); // Add a class to the delete cell
        const deleteImg = document.createElement('img');
        deleteImg.src = "./images/delete.svg";
        deleteImg.classList.add("delete-img");
        // console.log("quantity in cart is ",item.quantity);
        deleteCell.appendChild(deleteImg);
        row.appendChild(productImgCell);
        row.appendChild(descriptionCell);
        row.appendChild(priceCell);
        row.appendChild(quantityCell);
        row.appendChild(totalCell);
        row.appendChild(deleteCell);
        row.dataset.index = item.product_id;
        cartElement.appendChild(row);

      });
      // } catch (error) {
      //   console.log("Error parsing JSON data", error);
      // }
      addEventListeners();
    }

    function fetchCartItemsAndDisplay() {
      $.ajax({
  url: 'fetch_cart_items.php',
  method: 'POST',
  success: function(response) {
    try {
      // Try to execute the code that might cause errors
      console.log(response);
      displayCart(response); // Call function to display cart products
    } catch (error) {
      console.error('Error handling cart items response:', error);
      // Handle the error condition appropriately, such as displaying a message to the user
    }
  },
  error: function(xhr, status, error) {
    // Handle error response
    if (xhr.status === 401) {
      // Redirect to login page
      const emptyCartMessage = $("<h1>").addClass("empty-cart").text("OPPS!! YOU ARE NOT LOGGED IN");
      $(".cart").append(emptyCartMessage);
      
    } else {
      console.error('Error fetching cart items:', error);
      // Handle other errors
      if (error.startsWith("Your session has expired")) {
        // Redirect to login page
        window.location.href = 'login.php';
      } else {
        // Handle other errors
        alert('An error occurred while fetching cart items: ' + error);
      }
    }
  }
});

  }

    // Call fetchCartItemsAndDisplay function when the page loads
    // $(document).ready(function() {
    fetchCartItemsAndDisplay();
    // });

    const addEventListeners = () => {
      let prices = document.querySelectorAll(".price");
      let totals = document.querySelectorAll(".total");
      let quantities = document.querySelectorAll(".quantity");

      let final = 0;

      // document.querySelector('#shopMore').addEventListener('click', () => {
      //   window.location.href = "shop.php";
      // });

      const promoCodes = [{
          code: "PER#UME10",
          discount: 10
        },
        {
          code: "FR@Gran3",
          discount: 15
        },
        {
          code: "W0m3NB@ng",
          discount: 12
        },
        {
          code: "FALL15",
          discount: 15
        },
  
      ];

      console.log("loading")

      console.log(prices, totals);

      //CALCULATE TOTAL AMOUNT
      const totalAmount = () => {
        let itemCount = 0;
        let totalPrice = 0;
        for (let i = 0; i < totals.length; i++) {
          let price = parseFloat(prices[i].innerHTML.replace("₹", ""));
          let quantity = parseFloat(quantities[i].innerHTML);

          let total = price * quantity;
          totals[i].innerHTML = "₹" + total;

          totalPrice += total;
          itemCount += quantity;

          totalamount.innerHTML = "₹" + totalPrice;
          itemTotal.innerHTML = "ITEMs - " + itemCount;
          finalAmount.innerHTML = totalPrice;
          final += totalPrice;
        }
      };

      //CALCULATE TOTAL
      const totalPrice = (e, quantity, price) => {
        // console.log(e, quantity, price);
        total = price * quantity;
        console.log(total);
        e.target.parentElement.nextElementSibling.textContent = "₹" + total;
        totalAmount();
      };

      //INCREAMENT BUTTONS
      document.querySelectorAll(".increment").forEach((button) => {
        button.addEventListener("click", (e) => {
          console.log('click')
          let quantityElement = button.parentElement.querySelector(".quantity");
          let quantity = quantityElement.innerHTML;
          quantity++;
          quantityElement.innerHTML = quantity;
          let priceElement = e.target.parentElement.previousElementSibling;
          let price = parseFloat(priceElement.textContent.replace("₹", ""));
          showDelete(quantityElement, quantity);
          totalPrice(e, quantity, price);
          totalAmount();
        });
      });

      //DECREAMENT BUTTONS
      document.querySelectorAll(".decrement").forEach((button) => {
        button.addEventListener("click", (e) => {
          let quantityElement = button.parentElement.querySelector(".quantity");
          let quantity = quantityElement.innerHTML;
          quantity--;
          if (quantity >= 1) {
            quantityElement.innerHTML = quantity;


          } else {
            quantity = 0;
            quantityElement.innerHTML = 0;
          }
          let priceElement = e.target.parentElement.previousElementSibling;
          let price = parseFloat(priceElement.textContent.replace("₹", ""));
          // console.log(priceElement, price)
          showDelete(quantityElement, quantity);
          totalPrice(e, quantity, price);
        });
        totalAmount();
      });
      const showDelete = (quantityElement, quantity) => {
        const trElement = quantityElement.parentNode.parentNode;
        console.log(trElement)
        const deleBtn = trElement.querySelector('.delete img');
        if (quantity >= 1)
          deleBtn.style.display = 'none';
        else
          deleBtn.style.display = 'block';

      }



      document.querySelector("#apply").addEventListener("click", () => {
        let pcode = document.querySelector('input[name="Pcode"]').value;
        let promo = promoCodes.find((item) => item.code === pcode);
        if (promo) {
          let total = parseFloat(totalamount.innerHTML.replace("₹", ""));
          let discount = total * (promo.discount / 100);
          final = total - discount;
          final = Math.round(final);
          finalAmount.innerHTML = "₹" + final;
        } else {
          alert("Invalid Promo Code");
        }
      });
      finalAmount.innerHTML = "₹" + final;

      // FETCHING FROM DATABASE

     


      // Attach event listener to delete buttons
      $('.delete img').on('click', function() {
        // Get the parent row of the delete button
        const trElement = $(this).closest('tr');
        console.log(trElement)
        // Extract the product ID from the row ID
        const productId = trElement.data('index');
        console.log('Data Index:', productId);
        // Make AJAX call to delete the item from the cart
        $.ajax({
          url: 'cart_delete_item.php',
          method: 'POST',
          data: {
            productId: productId
          },
          success: function(response) {
            // Handle success response if needed
            console.log('Item deleted from cart:', response);
            // Hide the deleted row
            trElement.remove();
          },
          error: function(xhr, status, error) {
            // Handle error response if needed
            console.error('Error deleting item from cart:', error);
          }
        });
      });



    }
    

    document.addEventListener("DOMContentLoaded", function() {
    // Attach event listener to a parent element that is always present in the DOM
    document.body.addEventListener('click', function(event) {
        // Check if the clicked element is #shopMore or one of its descendants
        if (event.target.closest('#shopMore')) {
            // Redirect to "shop.php"
            window.location.href = "shop.php";
        }
    });
});



    // Function to show the loading popup
    function showLoadingPopup() {
        // Create a div for the loading popup
        var loadingPopup = document.createElement('div');
        loadingPopup.id = 'loading-popup';
        loadingPopup.innerHTML = '<p><b>TAKING YOU TO THE PAYMENT PAGE<b><br> <b>PLEASE WAIT...</b></p>';

        // Add CSS styles to enhance visual appeal
        loadingPopup.style.position = 'fixed';
        loadingPopup.style.top = '30%';
        loadingPopup.style.left = '35%';
        loadingPopup.style.transform = 'translate(-50%, -50%)';
        loadingPopup.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
        loadingPopup.style.padding = '40px'; /* Increase padding for a larger popup */
        loadingPopup.style.width = '300px'; /* Increase width */
        loadingPopup.style.borderRadius = '20px'; /* Increase border radius */
        loadingPopup.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.3)'; /* Add subtle shadow */
        loadingPopup.style.textAlign = 'center';
        loadingPopup.style.zIndex = '9999';
        loadingPopup.style.animation = 'pulsate 1s infinite'; /* Add pulsating animation */
        
        // Append the loading popup to the body
        document.body.appendChild(loadingPopup);
    }

    // Function to hide the loading popup
    function hideLoadingPopup() {
        var loadingPopup = document.getElementById('loading-popup');
        if (loadingPopup) {
            loadingPopup.remove();
        }
    }

    // Add event listener to the checkout button
    document.getElementById('checkout').addEventListener('click', function() {
        // Show the loading popup when the checkout button is clicked
        showLoadingPopup();

        // Simulate a delay to mimic the redirection process
        setTimeout(function() {
            // Redirect the user to the payment page
            window.location.href = 'payment_page.php';

            // After redirection, hide the loading popup
            hideLoadingPopup();
        }, 300000); // Adjust the delay time as needed
    });



  </script>
</body>

</html>