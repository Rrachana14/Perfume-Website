
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Eligibility Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9e6e6; /* Light pink background */
        }

        h2 {
            text-align: center;
            font-size: 28px; /* Larger font size */
            font-weight: bold; /* Bold */
            color: #FC6C85; /* Dark pink color */
            text-decoration: underline; /* Underline */
            font-style: italic; /* Italic */
            margin-bottom: 20px; /* Spacing */
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff; /* White container background */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .message {
            margin-bottom: 20px;
        }

        /* Red Flash */
        .message .error {
            color: #cc0000; /* Red color */
            animation: flash 1s infinite alternate; /* Flashing animation */
            font-weight: bold; /* Bold */
            text-decoration: underline; /* Underline */
        }

        /* Green Flash */
        .message .success {
            color: #006600; /* Green color */
            animation: flash 1s infinite alternate; /* Flashing animation */
            font-weight: bold; /* Bold */
            font-style: italic; /* Italic */
        }

        /* Flashing Animation */
        @keyframes flash {
            0% {
                opacity: 1;
            }
            100% {
                opacity: 0.1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Student Discount Eligibility</h2>

        <!-- PHP page response -->
        <div class="message">
            <?php
            // Perform only if POST method
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $n1 = $_POST['nam'];
                $a1 = intval($_POST['ag']);
                $e1 = $_POST['edu'];

                echo "<p><b>Welcome <i>$n1</i></b></p>"; 
                echo "<p><b>Age: <i>$a1</i></b></p>"; 
                if ($a1 < 15 || $a1 >= 25) {
                    echo "<p class='error'>Sorry! Age restrictions. You are not eligible for Discount !!</p>"; // RED FLASHES BOLD 
                } else {
                    echo "<p class='success'>Welcome!! You are eligible for Student Discount!!</p>"; // GREEN FLASHES BOLD
                    echo "<p><b>We will verify your Student Id of <i>$e1</i> and we will send you an email regarding the further process! </b></p>";
                }
                echo "<p><b><center><h3>Thanks for using our system</h3></center></b></p>";
                echo "<p><b><center><h3>Job Done!!</h3></center></b></p>";
            }
            ?>
        </div>
    </div>
</body>
</html>
