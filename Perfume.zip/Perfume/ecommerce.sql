-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2024 at 09:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`cart_id`, `product_id`, `user_id`, `quantity`) VALUES
(7, 1, 1, 1),
(8, 3, 2, 1),
(9, 1, 3, 1),
(11, 7, 1, 1),
(12, 5, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'Perfume'),
(2, 'Deodrant'),
(3, 'Body Mist'),
(4, 'Attar');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orders_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `prod_name` varchar(255) DEFAULT NULL,
  `prod_description` text DEFAULT NULL,
  `prod_price` decimal(10,2) DEFAULT NULL,
  `prod_stock` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `manufacturer_details` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `prod_name`, `prod_description`, `prod_price`, `prod_stock`, `category_id`, `image_url`, `manufacturer_details`) VALUES
(1, 'Carlton London', 'Carlton London Euphoria Perfume', 400.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/25754148/2023/12/13/ac0ef319-3859-4e41-b33f-0c75f585380b1702462159645-Carlton-London-Euphoria-Women-Gift-Set-of-4-EDP-Perfume---30-6.jpg', 'A bold and refreshing fragrance that captures the essence of masculinity. Perfect for everyday wear or special occasions.\r\nCarlton London offers a wide range of premium fragrances crafted with the finest ingredients to ensure long-lasting and luxurious perfumes'),
(2, 'DJOKR', 'DJOKR Signature Eau De Parfum for Men ', 350.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/26753120/2024/3/2/a3cadbac-7f07-4be5-acc9-fc91a87867ef1709363282780-DJOKR-Men-Signature-Long-Lasting-Eau-De-Parfum---100-ml-9701-1.jpg', 'A captivating blend of woody and spicy notes that leave a lasting impression. Ideal for the modern man who exudes confidence and style.\r\nDJOKR takes pride in creating unique and alluring fragrances for individuals who dare to stand out from the crowd.'),
(3, 'Burberry', 'Burberry SKINN For Women', 499.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/11785242/2022/8/1/ec1d3724-61b2-444e-b7c8-bd174d5623aa1659356765418SKINNbyTitanWomenCelesteFragrance-50ML1.jpg', 'A sophisticated and timeless fragrance that evokes the elegance of the Burberry brand. With its blend of floral and woody notes, it is perfect for any occasion.\r\nBurberry is renowned for its iconic British style and commitment to quality. Each fragrance is carefully crafted to reflect the brand\'s heritage and innovation.'),
(4, 'DJOKR', 'DJOKR Eau De Parfum For Men', 959.00, 100, 1, './images/product6.webp', 'A bold and invigorating fragrance that exudes confidence and charisma. With its blend of citrus and musk, it leaves a lasting impression wherever you go.\r\nDJOKR is dedicated to creating high-quality fragrances that inspire confidence and individuality. Each scent is carefully crafted to capture the essence of modern luxury.'),
(5, 'HVNLY', 'HVNLY Eau De Unisex Perfume ', 499.00, 100, 1, 'https://assets.myntassets.com/f_webp,h_560,q_90,w_420/v1/assets/images/24977534/2023/9/14/29f3c6cd-3451-45d5-a36d-8d415b35fd741694686244442HVNLYPleasureWomenEauDeParfum30ml1.jpg', 'A delightful and enchanting fragrance that transports you to a world of blissful serenity. With its blend of floral and fruity notes, it is perfect for everyday wear.\r\n\r\nHVNLY creates luxurious fragrances that capture the essence of pure indulgence. Each scent is crafted with care and precision to evoke a sense of joy and sophistication.'),
(6, 'PERFUME LOUNGE', 'PERFUME LOUNGE Eau De Parfum For Women', 1249.00, 100, 1, 'https://assets.myntassets.com/f_webp,h_560,q_90,w_420/v1/assets/images/12857380/2023/6/2/7f46587c-8358-45cc-a637-24e317dcfd2e1685706979915-Liberty-Women-Eden-Eau-De-Parfum-100-ml-8431685706979837-7.jpg', 'Experience the ultimate in luxury with PERFUME LOUNGE. With its intoxicating blend of floral and oriental notes, it is sure to leave a lasting impression.\r\n\r\nPERFUME LOUNGE is committed to creating exquisite fragrances that elevate the senses and evoke a sense of opulence and sophistication.'),
(7, 'Carlton London', 'Carlton London Limited Edition Eau De Parfum  ', 2000.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_2.0,q_60,w_210,c_limit,fl_progressive/assets/images/15455764/2022/12/28/20f9132e-3229-45ef-8b10-5df4003eaedc1672216534937-Carlton-London-Women-Limited-Edition-Lush-Eau-De-Parfum-100--1.jpg', 'Indulge in the luxurious scent of Carlton London Limited Edition. With its blend of floral and woody notes, it is perfect for those special occasions.\r\nCarlton London is synonymous with elegance and sophistication. Each fragrance is meticulously crafted to reflect the brand\'s timeless appeal and exquisite craftsmanship.'),
(8, 'Bella Vita', 'Bella Vita Spiced Amber Eau De Toilette  ', 648.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_2.0,q_60,w_210,c_limit,fl_progressive/assets/images/28068382/2024/3/6/fb7e935b-d928-4c14-a3e5-ec951a4962971709732794883BodyMistandSpray1.jpg', 'A captivating and alluring fragrance that captivates the senses. With its warm and spicy notes, it is perfect for both men and women.\r\nBella Vita is dedicated to creating luxurious fragrances that inspire confidence and allure. Each scent is carefully curated to evoke a sense of sophistication and elegance.'),
(9, 'Burberry', 'Burberry SKINN for Men and Women', 648.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6805521/2019/9/27/20b6cfe0-ab84-41f0-9ac9-14702f081bf51569578749127-Skinn-by-Titan-Set-of-2-Verge--Sheer-Perfumes-for-His--Her-2-1.jpg', 'A modern and sophisticated fragrance that captures the essence of Burberry\'s iconic style. With its blend of spicy and floral notes, it is perfect for any occasion.\r\nBurberry is renowned for its timeless elegance and innovative designs. Each fragrance is crafted with care and precision to reflect the brand\'s heritage and luxury.'),
(10, 'HVNLY', 'HVNLY Limited Edition Perfume For Women ', 3200.00, 100, 1, 'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/24977514/2023/9/15/9d0e88b3-1d0e-42c8-9078-0e2821635ec71694751774836HVNLYGraceWomenEauDeParfum30ml1.jpg', 'A refreshing and invigorating fragrance that revitalizes the senses. With its blend of citrus and herbal notes, it is perfect for those who appreciate natural beauty.\r\nHVNLY is committed to creating organic and cruelty-free fragrances that celebrate the beauty of nature. Each scent is crafted with sustainably sourced ingredients to ensure a pure and ethical product experience.');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_path`) VALUES
(19, 1, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/25754148/2023/11/20/4f91f1f8-4ca6-4704-ac81-5e81aa08e3221700480426124-Carlton-London-Euphoria-Women-Gift-Set-of-4-EDP-Perfume---30-5.jpg'),
(20, 1, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/25754148/2023/12/13/57f0c6a3-8069-4871-ae74-d80198916d641702462159635-Carlton-London-Euphoria-Women-Gift-Set-of-4-EDP-Perfume---30-7.jpg'),
(21, 1, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/25754148/2023/12/13/f561ec5d-6a79-43d4-a3ce-c845df371b081702462159598-Carlton-London-Euphoria-Women-Gift-Set-of-4-EDP-Perfume---30-14.jpg'),
(22, 2, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/26753120/2024/3/2/23c5e338-c95d-4298-b4a2-50b0b6b1649b1709363282775-DJOKR-Men-Signature-Long-Lasting-Eau-De-Parfum---100-ml-9701-2.jpg'),
(23, 2, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/26753120/2024/3/2/561320f1-0337-4071-9edf-78f14c1e1c8c1709363282769-DJOKR-Men-Signature-Long-Lasting-Eau-De-Parfum---100-ml-9701-3.jpg'),
(24, 2, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/26753120/2024/3/2/33908732-667d-48e4-813f-03318e9360291709363282751-DJOKR-Men-Signature-Long-Lasting-Eau-De-Parfum---100-ml-9701-6.jpg'),
(25, 10, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24977524/2023/9/14/88cfb9e1-c634-457e-bd50-8e19839266f21694679671340HVNLYGraceWomenEauDeParfum100ml2.jpg'),
(26, 10, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24977524/2023/9/14/7847a667-e307-4668-b6b8-fd875d8a98b81694679671323HVNLYGraceWomenEauDeParfum100ml4.jpg'),
(27, 10, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24977524/2023/9/14/b30a342f-2053-455c-8443-6c87bf4e7dbe1694679671394HVNLYGraceWomenEauDeParfum100ml6.jpg'),
(28, 5, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24977534/2023/9/14/71548130-67b9-42e8-afca-61e602c458091694686244425HVNLYPleasureWomenEauDeParfum30ml2.jpg'),
(29, 5, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24977526/2023/9/14/c62fedf5-8c0e-41b8-ae38-97ab6be178d31694684245879HVNLYCharmMenEauDeParfum100ml1.jpg'),
(30, 7, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/15455764/2022/12/28/8d12b7d3-2dbc-4f98-b4ab-be675d17613e1672216534901-Carlton-London-Women-Limited-Edition-Lush-Eau-De-Parfum-100--3.jpg'),
(31, 8, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/28068382/2024/3/6/142d356f-5c41-4079-95f7-42c8227d42231709732794869BodyMistandSpray2.jpg'),
(32, 8, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/28068382/2024/3/6/8ed6f1a3-cb50-47d7-b08c-c479ef5abe391709732794877BodyMistandSpray3.jpg'),
(33, 8, 'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/28068382/2024/3/6/2b250cff-e005-4622-bfc8-ff720dfd89511709732794895BodyMistandSpray4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_gender` enum('male','female','other') NOT NULL,
  `user_phone` bigint(15) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_dob` date DEFAULT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `how_hear_about_us` varchar(255) DEFAULT NULL,
  `selected_smells` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_gender`, `user_phone`, `user_address`, `user_dob`, `user_email`, `user_password`, `how_hear_about_us`, `selected_smells`) VALUES
(1, 'Vanshika Yadav ', 'female', 8200337433, 'Delhi', '2004-01-30', 'van@gmail.com', 'van31', 'Friend or Family referral', 'First Rain, Floral'),
(2, 'Rachana Rajiwade', 'female', 8372446689, 'Mumbai', '2004-06-14', 'rach@gmail.com', 'rach14', 'Social Media', 'First Rain, Mud'),
(3, 'Gaatha Yadav', 'female', 1234567890, 'Mumbai', '2008-03-11', 'gagu@gmail.com', 'g11', 'Online Search', ', Mud, Fruity');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orders_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orders_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cart_items_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `cart_items_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
