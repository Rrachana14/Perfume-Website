<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Database connection parameters
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "ecommerce";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Get user credentials from the form
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Query to check if user exists with the provided email and password
  $sql = "SELECT * FROM users WHERE user_email='$email' AND user_password='$password'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // User authenticated, set session variables and redirect to dashboard
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $email;
    header("Location: index.php");
  } else {
    // Authentication failed, redirect back to login page with error message
    $_SESSION['login_error'] = "Invalid email or password.";
    // header("Location: login.php");
  }

  // Close connection
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login page</title>
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    .main {
      width: 100%;
      height: 100vh;
      display: flex;
    }

    .left {
      width: 40%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;

    }

    h2 {
      font-size: 30px;
      margin-top: 170px;
      margin-bottom: 20px;
    }

    form {
      width: 60%;
      min-height: 40vh;
      /* background-color: aquamarine; */
      padding: 20px;
    }

    form h3 {
      margin: 10px 0;
    }

    input {
      width: 90%;
      padding: 10px 20px;
      margin-bottom: 20px;
      /* border: none; */
    }

    input:hover {
      border: 3px solid pink;
    }

    button {
      width: 100%;
      padding: 5px 15px;
      background-color: pink;
      border: 1px solid rgb(255, 192, 203);
      margin-bottom: 30px;
    }

    .flex-box {
      display: flex;
      align-items: center;
      margin: 2px auto;

    }

    .logbtn {
      display: flex;
      width: 70%;
      margin: auto 10px;
      padding: auto;
      background-color: pink;
      border: 2px solid black;
      cursor: pointer;
      border-radius: 4em;
      justify-content: center;
    }

    .logbtn h4 {
      color: black;
      font-size: 18px;
    }

    .logbtn img {
      height: 20px;
      margin-right: 15px;
    }

    .right {
      width: 60%;
      height: 100%;
      background-color: pink;

    }
  </style>
</head>

<body>
  <div class="main">
    <div class="left">
      <h2>Welcome back!</h2>
      <form id="login" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <h3>Email Address</h3>
        <input type="email" placeholder="Enter your email address" name="email" value="">
        <h3>Password</h3>
        <input type="password" placeholder="Enter your password" name="password" value="">
        <?php
        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          // Database connection parameters
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "ecommerce";

          // Create connection
          $conn = new mysqli($servername, $username, $password, $dbname);

          // Check connection
          if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }

          // Get user credentials from the form
          $email = $_POST['email'];
          $password = $_POST['password'];

          // Query to check if user exists with the provided email and password
          $sql = "SELECT * FROM users WHERE user_email='$email' AND user_password='$password'";
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
            // User authenticated, set session variables and redirect to dashboard
            $row = $result->fetch_assoc();
            $user_id = $row['user_id'];
            $_SESSION['loggedin'] = true;
            $_SESSION['email'] = $email;
            $_SESSION['user_id'] = $user_id;
            
            header("Location: index.php");
            exit();
          } else {
            // Authentication failed, redirect back to login page with error message
            $_SESSION['login_error'] = "Invalid email or password.";
            echo '<p style="color:red;">Invalid Username or password</p>';
            // header("Location: login.php");
            
          }

          // Close connection
          $conn->close();
        }

        ?>
        <button>
          <h3>Login</h3>
        </button>
        <div class="flex-box">
          <button class="logbtn"><img src="./images/google.svg">
            <h4>Google</h4>
          </button>
          <button class="logbtn"><img src="./images/facebook.svg">
            <h4>Facebook</h4>
          </button>
        </div>
	<br>
	<br>
	<p><b><center><h3> Don't have an account? <a href="signup.php">Sign up</a> </p></b></center></h3>

      </form>
    </div>
    <div class="right"></div>
  </div>
</body>

</html>