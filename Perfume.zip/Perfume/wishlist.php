<?php

// Start session
session_start();

// Check if it's a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data sent from JavaScript
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Get user ID from session
        $userId = $_SESSION['user_id'];

        $data = json_decode(file_get_contents("php://input"));

        // Check if the product is already in the wishlist
        $productId = $data->productId;
        $isAdded = $data->isAdded;

        try {
            if ($isAdded) {
                // Add product to wishlist
                addToWishlist($userId, $productId);
            } else {
                // Remove product from wishlist
                removeFromWishlist($userId, $productId);
            }

            // Respond with success
            echo json_encode(array("success" => true));
        } catch (Exception $e) {
            // Respond with error if an exception occurs
            echo json_encode(array("success" => false, "error" => "Failed to update wishlist"));
        }
    } else {
        // Respond with error if user is not logged in
        echo json_encode(array("success" => false, "error" => "User not logged in"));
    }
} else {
    // Respond with error if it's not a POST request
    echo json_encode(array("success" => false, "error" => "Method not allowed"));
}

// Function to add product to wishlist
// Function to add product to wishlist
function addToWishlist($userId, $productId) {
    // Establish database connection
    $servername = "localhost";
    $username = "root"; // Your database username
    $password = ""; // Your database password
    $dbname = "ecommerce"; // Your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to insert into wishlist table
    $sql = "INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $productId);

    // Execute SQL statement
    $stmt->execute();

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

// Function to remove product from wishlist
function removeFromWishlist($userId, $productId) {
    // Establish database connection
    $servername = "localhost";
    $username = "root"; // Your database username
    $password = ""; // Your database password
    $dbname = "ecommerce"; // Your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to delete from wishlist table
    $sql = "DELETE FROM wishlist WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $productId);

    // Execute SQL statement
    $stmt->execute();

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

?>
