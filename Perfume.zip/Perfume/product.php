<?php
session_start();
error_log("Cart page accessed.");
// $userId = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Product Page</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="nav.css" />
  <link rel="stylesheet" href="footer.css">
  <link rel="stylesheet" href="productCard.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Arimo:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet" />
  <script>
    $(document).ready(function() {
      // Your code for the "rlogo" hover effect
      $(".rlogo").hover(
        function() {
          $(this).find("h5").css({
            top: "calc(100% + 10px)",
            opacity: "1",
            transform: "translate(-50%, -10px)",
          });
        },
        function() {
          $(this).find("h5").css({
            top: "110%",
            opacity: "0",
            transform: "translate(-50%, 130%)",
          });
        }
      );

      // Your code for the "perf" and "perfume" hover effect
      $("#perf").mouseenter(function() {
        $("#perfume").slideDown("slow");
      });

      $("#perf").mouseleave(function() {
        $("#perfume").slideUp("slow");
      });

      $("#perfume").mouseenter(function() {
        $("#perfume").slideDown("slow");
      });

      $("#perfume").mouseleave(function() {
        $("#perfume").slideUp("slow");
      });

      // Your code for the "signin" click and mouseleave effect
      $("#signin").click(function() {
        $(".signin").slideToggle("slow");
      });

      $(".signin").mouseleave(function() {
        $(".signin").slideUp("slow");
      });
    });
  </script>
</head>
<style>
  body {
    background-color: #eeeeee;
    font-family: sans-serif;
    position: relative;
  }

  /* ALERT  */
  .alert-success {
    display: none;
    position: fixed;
    text-align: center;
    align-items: center;
    top: 80px;
    left: 10px;
    z-index: 99;
    /* opacity: 0; */
    transition: all 0.5s ease-in-out;
    /* Change transition property */
    /* animation: pop  0.5s  ease-in-out; */
    animation-name: pop;
    animation: pop 0.5s ease;
    background-color: greenyellow;
    padding: 10px 20px;
    border-radius: 5px;
  }

  .alert-success a {
    font-size: 22px;
    margin-left: 10px;
    text-decoration: none;
    font-size: 16px;
    color: black;
  }

  .alert-success.show {
    display: flex;
    /* Show the alert */
    opacity: 1;
  }

  @keyframes pop {
    0% {
      transform: scale(0);
    }

    25% {
      transform: scale(0.5);
    }

    50% {
      transform: scale(2);
    }

    75% {
      transform: scale(1.5);
    }

    100% {
      transform: scale(1);
    }
  }

  /* LOGIN POP BOX */
  .login-box h3 {
    font-size: 20px;
    color: white;
  }

  .login-box {
    /* width: 230px; */
    /* height:100px; */
    display: none;
    background: linear-gradient(to bottom, #588157, #344e41);
    padding: 15px 15px;
    border-radius: 10px;
    position: fixed;
    top: 50%;
    left: 40%;
    z-index: 99;
    animation-name: pop;
    transition: all 0.5s ease-in-out;
    animation: pop 0.5s ease;
  }

  .login-box .flex {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 20px;
  }

  .login-box button {
    padding: 10px 15px;
    border: none;
    margin-right: 20px;
    font-weight: 600;
    font-size: 19px;
    background-color: #a3b18a;
    color: white;
    cursor: pointer;
    border-radius: 5px;
  }

  .login-box button:hover {
    background: linear-gradient(to right, #40916c, #a3b18a);
  }

  #overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    /* Semi-transparent grayish overlay */
    z-index: 1000;
    /* Ensure the overlay appears above other content */
    display: none;
    z-index: 90;
  }

  /* PRODUCT CONTAINER */
  .product-container {
    width: 95%;
    height: 70vh;
    display: flex;
    padding: 0 15px;
    border-bottom: 2px solid #cac6c7;
    margin-bottom: 25px;
  }

  .product-left {
    width: 40%;
  }

  .product-left img {
    width: 70%;
    height: 74%;
    margin: 5px 65px;
    align-self: center;
    object-fit: cover;
  }

  .product-img {
    display: flex;
    height: 105px;
    width: 100%;
    align-items: center;
    padding: 0 40px;
  }

  .product-img img {
    height: 90%;
    width: 90px;
    margin: 0 10px;
  }

  .prod-active {
    transform: scale(1.2);
    box-shadow: 2px 2px 6px #cecccc;
  }

  .product-right {
    width: 60%;
    height: 100%;
    padding: 10px 20px;
    position: relative;
  }

  .product-right h2 {
    font-size: 40px;
    text-transform: uppercase;
    padding: 3px 0px;
    border-bottom: 2px solid black;
    font-family: "Arimo", sans-serif;
    font-optical-sizing: auto;
    font-style: normal;
    /* margin-bottom: 35px; */
  }

  .available {
    padding: 5px 14px;
    display: inline-block;
    border-radius: 50px;
    text-transform: capitalize;
    background-color: #bebebe;
    font-size: 14px;
    position: absolute;
    top: 14%;
    right: 3%;
  }

  .product-flex {
    width: 100%;
    height: 50px;
    display: flex;
    align-items: center;
  }

  .prices p,
  .prod-qauntity p {
    font-size: 14px;
    margin: 3px;
  }

  .prices h4 {
    font-size: 32px;
    font-weight: 800;
  }

  .prod-qauntity {
    margin-left: 150px;
  }

  .quantity {
    width: 150px;
    padding: 10px 20px;
    border-radius: 30px;
    background-color: #e8e7e7;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-right: 20px;
  }

  .quantity button {
    background-color: #f1f1f1;
    padding: 3px 12px;
    border-radius: 50%;
    border: none;
    box-shadow: inset 2px 0px 5px 2px #e7e6e6;
    font-size: 20px;
    font-weight: 700;
  }

  .prod-info {
    width: 100%;
    height: 30vh;
    /* position: absolute; */
    /* margin-top: 10px; */

    height: 70%;
  }

  .select-box {
    display: flex;
    font-weight: 500;
    border-bottom: 1px solid gray;
  }

  .prod-info h3 {
    font-size: 17px;
    margin-top: 30px;
    margin-right: 20px;
    padding: 3px 8px;
    cursor: pointer;
    /* color: grey; */
    /* font-weight: 400; */
  }

  .description,
  .details {
    margin-top: 20px;

  }

  .details {
    display: none;
  }

  .display-active {
    color: black;
    font-weight: bold;
    font-weight: 900;
  }

  .details label {
    font-size: 18px;
    font-weight: 600;
    color: black;
  }

  .prod-buttons {
    display: flex;
    position: absolute;
    bottom: 10%;

  }

  .prod-buttons button {
    padding: 10px 20px;
    margin-right: 20px;
    font-weight: 600;
    font-size: 17px;
    border: 2px solid black;
    cursor: pointer;
  }

  .prod-buttons .cart {
    background-color: #000000;
    color: white;
  }

  /* SIMILAR PRODUCTS */
  .heading {
    font-size: 20px;
    margin: 0 35px;
  }

  .similar-products {
    width: 100%;
    min-height: 100vh;
    padding: 10px 30px;
  }
</style>

<body>

  <div class="login-box">
    <h3>YOU ARE NOT LOGGED IN</h3>
    <div class="flex">
      <button id="login-page">Login Now</button>
      <button id="cancel">Cancel</button>
    </div>
  </div>
  <div id="overlay"></div>
  <!-- NAV -->
  <nav>
    <img class="logo" src="./images/logo.png" />
    <ul class="slide">
      <li><a href="index.php">Home</a></li>
      <li class="flip " id="perf"><a href="shop.php">Perfume</a></li>
      <table class="menu" id="perfume">
        <tr>
          <th>Perfume</th>
          <th>Combo</th>
          <th>Gifts</th>
        </tr>
        <tr>
          <td><a href="#">Best Seller</a></td>
          <td><a>New Combo</a></td>
          <td><a>Gift Sets</a></td>
        </tr>
        <tr>
          <td><a href="#">Regular Perfume</a></td>
          <td><a>Festival Special Combo</a></td>
        </tr>
        <tr>
          <td><a href="#">Permium Perfume</a></td>
          <td><a>Best Deals</a></td>
        </tr>
        <tr>
          <td><a href="#">Contact</a></td>
        </tr>
      </table>
      <li><a href="deodrant.php">Deodrant</a></li>
      <li><a>Body Mist</a></li>
      <li><a>Attar</a></li>
    </ul>
    <div class="nav-search">
      <input type="text" placeholder="Enter here" />
      <img src="./images/search-4-svgrepo-com.svg" />
    </div>
    <div class="right">
      <div class="rlogo" id="signin">
        <img src="./images/profile-svgrepo-com - Copy.svg" />
        <h5>Profile</h5>
        <div class="signin">
          <div class="logged">
            <?php
            // session_start();
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "ecommerce";

              // Create connection
              $conn = new mysqli($servername, $username, $password, $dbname);

              // Check connection
              if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
              }

              // Retrieve user data from the database based on their email
              $email = $_SESSION['email']; // Assuming 'email' is the session variable containing the user's email
              $sql = "SELECT * FROM users WHERE user_email='$email'";
              $result = $conn->query($sql);

              if ($result->num_rows > 0) {
                // User data found, display or use it as needed
                $userData = $result->fetch_assoc();
                // Example: Display the user's name
                echo '<h4>Welcome,' . $userData['user_name'] . '</h4>';
                echo '<div class="signbox">';
                echo '<a href="logout.php">Logout</a>';
                echo '</div>';
              } else {
                // User data not found
                echo 'Welcome to our website!';
              }

              // Close connection
              $conn->close();
            } else {
              // If user is not logged in, display signup and login links
              // echo '<img src="./images/profile-svgrepo-com - Copy.svg" />';
              // echo '<h5>Profile</h5>';

              echo '<div class="signbox">';
              echo '<a href="signup.php">SIGNUP</a>';
              echo '</div>';
              echo '<div class="signbox">';
              echo '<a href="login.php">LOGIN</a>';
              echo '</div>';
            }
            ?>
          </div>
          <div class="logged">
            <ul>
              <li><a href="">Orders</a></li>
              <li><a href="">Wishlist</a></li>
              <li><a href="">Gift Cards</a></li>
              <li><a href="">Contact Us</a></li>
            </ul>
          </div>
          <div class="logged">
            <ul>
              <li><a href="">Coupons</a></li>
              <li><a href="">Saved</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="rlogo" id="rlogo">
        <img src="./images/heart-svgrepo-com.svg" id="whishlistbtn" />
        <a href="#">
          <h5>Wishlist</h5>
        </a>
      </div>
      <div class="rlogo" id="rlogo">
        <img src="./images/bag-shopping-svgrepo-com - Copy.svg" id="cartbtn" />
        <a href="calculator.php">
          <h5>Cart</h5>
        </a>
      </div>
    </div>
  </nav>
  <div class="alert alert-success alert-dismissible">
    <h6><strong>Heyy!</strong> Item succesfully added in the cart.</h6>
    <!-- <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> -->
  </div>

  <!-- PRODUCT CONTAINER -->
  <div class="container">
    <?php
    // Connect to the database
    $pdo = new PDO('mysql:host=localhost;dbname=ecommerce', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if product ID is provided in the URL
    if (isset($_GET['id'])) {
      // Retrieve product ID from the URL
      $productId = $_GET['id'];

      // Prepare and execute the SQL statement to fetch product details
      $stmt = $pdo->prepare('SELECT * FROM Products WHERE product_id = ?');
      $stmt->execute([$productId]);


      // Fetch the product details
      $product = $stmt->fetch(PDO::FETCH_ASSOC);

      // Check if product exists
      if ($product) {
        // Output the product card HTML
    ?>
        <div class="product-container" data-index="<?php echo $productId; ?>">
          <div class="product-left">
            <img class="main-img" src="<?php echo $product['image_url']; ?>" alt="product img" />
            <div class="product-img">
              <img src="<?php echo $product['image_url']; ?>" class="prod-active" />
              <?php

              // Prepare and execute SQL statement to fetch three images for this product
              $stmt_images = $pdo->prepare('SELECT image_path FROM product_images WHERE product_id = ? LIMIT 3');
              $stmt_images->execute([$productId]);
              $images = $stmt_images->fetchAll(PDO::FETCH_ASSOC);

              // Output image elements
              foreach ($images as $image) {
              ?>
                <img src="<?php echo $image['image_path']; ?>" />
              <?php } ?>
            </div>
          </div>

          <div class="product-right">
            <h2 id="tag"><?php echo $product['prod_name']; ?></h2>
            <div class="available">available in stock</div>
            <div class="product-flex">
            </div>
            <div class="product-flex">
              <div class="prices">
                <p>PRICE</p>
                <h4 class="price">₹<?php echo $product['prod_price']; ?></h4>
              </div>
              <div class="prod-qauntity">
                <p>QUANTITY</p>
                <div class="quantity">
                  <button class="decrement">-</button>
                  <span class="qaunti">0</span>
                  <button class="increment">+</button>
                </div>
              </div>
            </div>
            <div class="prod-info">
              <div class="select-box">
                <h3 class="desc-btn display-active">DESCRIPTION</h3>
                <h3 class="det-btn">DETAILS</h3>
              </div>
              <div class="description">
                <p class="des"><?php echo $product['prod_description']; ?></p>
		<br>
                <p class="des"><?php echo $product['manufacturer_details']; ?></p>
                <!-- <p class="des"><?php echo $product['category_name']; ?></p> -->
              </div>
              <div class="details">
                <label>Scent Name:</label><?php echo $product['prod_name']; ?><br />
                <label>Size:</label> 50 ml (Pack of 1)<br />
                <label>Country of Origin :</label> France <br />
		<label>Item Weight:</label> 210g <br />
                <label>Item Dimensions LxWxH :</label> 8.5 x 4 x 10 Centimeters<br />
                <label>Net Quantity :</label>50 millilitre
              </div>
            </div>
            <div class="prod-buttons">
              <button class="cart addCart1">ADD TO CART</button>
              <button class="wishlist">ADD TO WISHLIST</button>
            </div>
          </div>
        </div>
    <?php
      } else {
        echo '<p>Product not found.</p>';
      }
    } else {
      echo '<p>No product ID provided.</p>';
    }

    // Close the database connection
    $pdo = null;
    ?>


    <!-- <div class="product-left">
        <img class="main-img" src="./images/product3.webp" alt="product img" />
        <div class="product-img">
          <img src="./images/product3.webp" class="prod-active" />
          <img src="./images/prod1.jpg" />
          <img src="./images/prod2.avif" />
          <img src="./images/prod3.webp" />
        </div>
      </div>
      <div class="product-right" data-index="">
        <h2 id="tag">Burberry</h2>
        <div class="available">available in stock</div>
        <div class="product-flex">
          <div class="prices">
            <p>PRICE</p>
            <h4 class="price">₹859</h4>
          </div>
          <div class="prod-qauntity">
            <p>QUANTITY</p>
            <div class="quantity">
              <button class="decrement">-</button>
              <span class="qaunti">0</span>
              <button class="increment">+</button>
            </div>
          </div>
        </div>
        <div class="prod-info">
          <div class="select-box">
            <h3 class="desc-btn display-active">DESCRIPTION</h3>
            <h3 class="det-btn">DETAILS</h3>
          </div>
          <div class="description">
            <p class="des">Spiced Amber Vegan Eau De Toilette - 100 ml</p>
            <p>
              Long-Lasting Freshness An Envious Blend Of Floral, Spicy, Aquatic,
              And Fruity Aroma Warm, Woody, And Sweet-Smelling Fragrance
            </p>
          </div>
          <div class="details">
            <label>Scent Name:</label>Floral <br />
            <label>Size:</label> 50 ml (Pack of 1)<br />
            <label>Country of Origin :</label> France <br />Item Weight 210 g
            <br />
            <label>Item Dimensions LxWxH :</label> 8.5 x 4 x 10 Centimeters<br />
            <label>Net Quantity :</label>50 millilitre
          </div>
        </div>
        <div class="prod-buttons">
          <button class="cart addCart">ADD TO CART</button>
          <button class="wishlist">ADD TO WISHLIST</button>
        </div>
      </div> -->
  </div>
  <!-- SIMILAR PRODUCTS -->
  <h3 class="heading">MORE PRODUCTS</h3>
  <div class="similar-products">
    <div class="product" data-index="9">
      <div class="wish"><i class="fa-solid fa-heart"></i></div>
      <img src="./images/product9.webp" />
      <h4 id="tag">DJOKR</h4>
      <p class="des">Djokr On The Rocks Perfume For Men 100 ml</p>
      <div class="prod-flex">
        <h5 class="price">₹100</h5>
        <button class="addCart">ADD TO CART</button>
      </div>
    </div>

    <!-- <div class="product" data-index="5">
      <div class="wish"><i class="fa-solid fa-heart"></i></div>
      <img src="./images/product5.webp" />
      <h4 id="tag">DJOKR</h4>
      <p class="des">Djokr On The Rocks Perfume For Men 100 ml</p>
      <div class="prod-flex">
        <h5 class="price">₹150</h5>
        <button class="addCart">ADD TO CART</button>
      </div>
    </div> -->

  </div>

  </div>
  <footer>
    <div class="footer-inner">
      <div class="footer-column">
        <img class="logo" src="./images/logo.png" />
        <br>
        <br>
        <h3><i>YOUR GATEWAY TO A WORLD OF CAPTIVATING AROMAS!</i></h3>

      </div>
      <div class="footer-column">
        <h2>Locate Us</h2>
        <p>
          <br>
          Fragrance Heaven Pvt Ltd,<br />
          A-142,Phase 1,MIDC,<br />
          Kalyan, Dt.Thane<br />
          Pin: 421306,Maharashtra,India<br />
        </p>
      </div>
      <div class="footer-column">
        <h2>Contact Us </h2>
        <p>
          <br>
          Email: fragranceheaven@gmail.com<br />
          Phone: 123-456-7890<br />

          <br>
        <h2> <a href="#">About Us</a> </h2>
        </p>
      </div>
      <div class="footer-column">
        <h2>Quick Links</h2>
        <br>
        <div class="column-wrapper">
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Perfume</a></li>
            <li><a href="#">Deodorant</a></li>
          </ul>
        </div>
        <div class="column-wrapper">
          <ul>
            <li><a href="#">Body Mist</a></li>
            <li><a href="#">Attar</a></li>
            <li><a href="#">Student Discount</a></li>
          </ul>
        </div>
      </div>

    </div>
    <div class="footer-bottom">
      <p>&copy; 2024, Fragrance Heaven . All Rights Reserved.</p>
    </div>
  </footer>
  <script src="nav.js"></script>
  <script>
    const mainImg = document.querySelector(".main-img");
    const images = document.querySelectorAll(".product-img img");
    let decbtns = document.querySelectorAll(".decrement");
    let incbtns = document.querySelectorAll(".increment");
    const quantity = document.querySelector(".qaunti");
    const similarProducts = document.querySelector('.similar-products');

    const toDisplayProduct = (products) => {
      similarProducts.innerHTML = "";
      products.forEach((product, index) => {

        const productElement = document.createElement('div');
        productElement.classList.add('product');

        const wishBox = document.createElement('div');
        wishBox.classList.add('wish');
        wishBox.innerHTML = `<i class="fa-solid fa-heart"></i>`;

        const productImage = document.createElement('img');
        productImage.src = product.image_url;
        const productTitle = document.createElement('h4');
        productTitle.setAttribute('id', 'tag');
        productTitle.innerHTML = product.prod_name;
        const productDescription = document.createElement('p');
        productDescription.innerHTML = product.prod_description;

        const flexBox = document.createElement('div');
        flexBox.classList.add('prod-flex');
        const productPrice = document.createElement('h5');
        productPrice.classList.add('price');
        productPrice.innerHTML = "₹" + product.prod_price;
        const cartBtn = document.createElement('button');
        cartBtn.classList.add('addCart');
        cartBtn.innerHTML = 'ADD TO CART';

        flexBox.appendChild(productPrice);
        flexBox.appendChild(cartBtn);

        const ratingElement = document.createElement('div');
        ratingElement.classList.add('rating');
        const ratingValue = Math.floor(Math.random() * 3) + 3; // Generate random rating from 1 to 5
        const stars = '★'.repeat(ratingValue) + '☆'.repeat(5 - ratingValue); // Create stars based on rating
        ratingElement.innerHTML = `${stars}`;


        productElement.appendChild(wishBox);
        productElement.appendChild(productImage);
        productElement.appendChild(productTitle);
        productElement.appendChild(productDescription);
        productElement.appendChild(flexBox)
        productElement.appendChild(ratingElement);
        productElement.dataset.index = product.product_id;
        similarProducts.appendChild(productElement)


        console.log(productElement)
      });
    }



    document.addEventListener("DOMContentLoaded", async () => {
      try {
        const response = await fetch('fetch_products.php');
        if (!response.ok) {
          throw new Error('Failed to fetch product data');
        }
        products = await response.json();
        toDisplayProduct(products);
        // Add event listener for product images
        document.querySelectorAll('.product img').forEach(prodImg => {
          prodImg.addEventListener('click', (e) => {
            const prodIndex = e.target.closest('.product').dataset.index;
            const prodTitle = e.target.closest('.product').querySelector('h4').innerHTML;
            const prodDescription = e.target.closest('.product').querySelector('p').innerHTML;
            const prodPrice = e.target.closest('.product').querySelector('.price').innerHTML;
            const url = `product.php?id=${prodIndex}`;
            window.location.href = url;
          });
        });

        //INCREAMENT BUTTONS
        document.querySelector(".increment").addEventListener("click", (e) => {
          let quantityElement = quantity.innerHTML;
          quantityElement++;
          quantity.innerHTML = quantityElement;
        });
        //DECREMENT BUTTONS
        document.querySelector(".decrement").addEventListener("click", (e) => {
          let quantityElement = quantity.innerHTML;
          quantityElement--;
          if (quantityElement >= 0) quantity.innerHTML = quantityElement;
          else quantity.innerHTML = 0;
        });


        // EVENLISTNER ON WISH-HEART
        document.querySelectorAll('.product').forEach((product) => {
          product.addEventListener('mouseenter', (e) => {

            // console.log(e.currentTarget.parentNode);
            const wish = e.currentTarget;
            heart = wish.querySelector('.wish i');
            heart.style.transform = 'scale(1)';
            // });
            product.addEventListener('mouseleave', (e) => {
              const wish = e.currentTarget;
              heart = wish.querySelector('.wish i');
              heart.style.transform = ' scale(0)';
            });
          })
        });
        document.querySelectorAll('.wish i').forEach((heart) => {
          heart.addEventListener('click', (e) => {
            e.preventDefault();
            if (heart.style.color == "white") {
              heart.style.color = "red";
            } else {
              heart.style.color = "white";
            }
          })
        })

        // FUNCTION TO ADD SIMILAR PRODUCTS INTO THE CART

        $(document).ready(function() {
          $('.addCart').click(function() {
            // Get product ID, quantity, and user ID
            console.log("click");
            var productContainer = $(this).closest('.product');
            var quantityElement = productContainer.find('.prod-flex .quantity');
            var quantity = quantityElement.length ? quantityElement.text().trim() : 1;
            console.log('Quantity:', quantity);
            // const prodQauntity = quantityElement ? quantityElement.innerHTML : 1;
            var productId = $(this).closest('.product').data('index');


            // var quantity = 1; // You can change this to get the actual quantity from the user interface

            <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) { ?>
              var userId = <?php echo $_SESSION['user_id']; ?>;
            <?php } else { ?>
              // Perform a specific action if userId is null or empty
              // For example, redirect the user to the login page
              // window.location.href = 'login.php';
              document.querySelector('.login-box').style.display = 'block'
              document.querySelector('#overlay').style.display = 'block';
            <?php } ?>

            // Send AJAX request to add product to cart
            $.ajax({
              url: 'addtocart.php',
              method: 'POST',
              data: {
                productId: productId,
                quantity: quantity,
                userId: userId
              },
              success: function(response) {
                // Handle success response
                // Check if response contains an error message
                if (response.startsWith("Error")) {
                  // Product already exists in the cart
                  alert(response);
                } else {
                  // Product added to cart successfully
                  document.querySelector(".alert-success").classList.add("show");
                  setTimeout(function() {
                    document.querySelector(".alert-success").classList.remove("show");
                  }, 3000);
                }
              },
              error: function(xhr, status, error) {
                // Handle error
                if (xhr.status === 401) {
                  // Redirect to login page
                  document.querySelector('.login-box').style.display = 'block';
                  document.querySelector('#overlay').style.display = 'block';
                } else {
                  console.error('Error adding product to cart:', error);
                  // Handle other errors
                }
              }
            });
          });
        });



      } catch (error) {
        console.error('Error fetching product data:', error);
      }
    });




    //FOR PRODUCT IMAGE CHANGE
    images.forEach((image) => {
      image.addEventListener("click", (e) => {
        mainImg.src = image.src;
        console.log(e.currentTarget);
        images.forEach((img) => img.classList.remove("prod-active"));
        e.currentTarget.classList.add("prod-active");
      });
    });

    // FUNCTION TO ADD MAIN PRODUCT INTO THE CART
    $(document).ready(function() {
      $('.addCart1').click(function() {
        
        const productContainer = $(this).closest('.product-container');

        const productId = productContainer.data('index');
        console.log('Data index:', productId);

        const cartBtn = $(this).parent();
        const prodFlex = cartBtn.parent();
        const productCon = prodFlex.parent();
        console.log(productCon)
        const con = $(this).closest('.product-right');
        const quantity = productCon.find(".qaunti").text() || 1;

        console.log("qauntity", quantity)
        //Send AJAX request to add product to cart
        <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) { ?>
          var userId = <?php echo $_SESSION['user_id']; ?>;
        <?php } else { ?>
         
          document.querySelector('.login-box').style.display = 'block';
          document.querySelector('#overlay').style.display = 'block';
        <?php } ?>
        $.ajax({
          url: 'addtocart.php',
          method: 'POST',
          data: {
            productId: productId,
            quantity: quantity,
            userId: userId
          },
          success: function(response) {

            if (response.startsWith("Error")) {
              // Product already exists in the cart
              alert(response);
            } else {
              document.querySelector(".alert-success").classList.add("show");
              setTimeout(function() {
                document.querySelector(".alert-success").classList.remove("show");
              }, 3000);
            }
          },
          error: function(xhr, status, error) {
            // Handle error
            if (xhr.status === 401) {
              // Redirect to login page
              // window.location.href = 'login.php';
              document.querySelector('.login-box').style.display = 'block';
              document.querySelector('#overlay').style.display = 'block';
            } else {
              console.error('Error adding product to cart:', error);
              // Handle other errors
            }
          }
        });
      });
    });


    document.querySelector('#login-page').addEventListener('click', () => {
      window.location.href = 'login.php';
    })

    document.querySelector('#cancel').addEventListener('click', () => {
      document.querySelector('.login-box').style.display = 'none';
      document.querySelector('#overlay').style.display = 'none';

    })



    //FOR PRODUCT INFO CHANGE
    const descripBtn = document.querySelector(".desc-btn");
    const detailBtn = document.querySelector(".det-btn");
    const descripDisplay = document.querySelector(".description");
    const detailDisplay = document.querySelector(".details");
    detailBtn.addEventListener("click", () => {
      detailBtn.classList.add("display-active");
      descripBtn.classList.remove("display-active");
      detailDisplay.style.display = "block";
      descripDisplay.style.display = "none";
    });
    descripBtn.addEventListener("click", () => {
      detailBtn.classList.remove("display-active");
      descripBtn.classList.add("display-active");
      descripDisplay.style.display = "block";
      detailDisplay.style.display = "none";
    });

    //INCREMENT AND DECREMENT


    // FUNCTION TO ADD PRODUCT IN THE CART
    // function addToCart(
    //   productId,
    //   productName,
    //   productDesp,
    //   productPrice,
    //   productQuantity
    // ) {
    //   const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
    //   let productExist = false;
    //   cartItems.forEach((item) => {
    //     if (item.productId === productId) {
    //       console.log(productId);
    //       // item.quantity ++;
    //       productExist = true;
    //     }
    //   });
    //   if (!productExist) {
    //     cartItems.push({
    //       productId,
    //       productName,
    //       productDesp,
    //       productPrice,
    //       productQuantity,
    //     });
    //     $(".alert").addClass("show");
    //     // confirm("Product added in the cart");
    //     document.querySelector(".alert-success").classList.add("show");
    //     setTimeout(function() {
    //       document.querySelector(".alert-success").classList.remove("show");
    //     }, 3000);
    //   }
    //   localStorage.setItem("cartItems", JSON.stringify(cartItems));
    // }

    // document.querySelectorAll(".addCart").forEach((button, index) => {
    //   button.addEventListener("click", (e) => {
    //     const cartBtn = e.target;
    //     const prodFlex = cartBtn.parentNode;
    //     const productContainer = prodFlex.parentNode;
    //     const index = productContainer.dataset.index;
    //     const prodTitle = productContainer.querySelector("#tag").innerHTML;
    //     const prodDescription =
    //       productContainer.querySelector(".des").innerHTML;
    //     const prodPrice = productContainer.querySelector(".price").innerHTML;
    //     const classList = productContainer.classList;
    //     const quantityElement = productContainer.querySelector(".qaunti");
    //     const prodQauntity = quantityElement ? quantityElement.innerHTML : 1;

    //     console.log("index and quantity", index, prodQauntity);
    //     console.log(productContainer.querySelector("#tag").innerHTML);
    //     console.log(productContainer.querySelector(".des").innerHTML);
    //     console.log(productContainer.querySelector(".price").innerHTML);
    //     // console.log(prodQauntity);

    //     console.log(index);
    //     cartBtn.disabled = true;
    //     addToCart(index, prodTitle, prodDescription, prodPrice, prodQauntity);
    //   });
    // });

    // var productContainer = $(this).closest('.product');
    // var productId;
    //     $('.product[data-index!=""]').each(function() {
    //       productId = $(this).attr('data-index');
    //     });
    //     console.log('Data index:', productId);


    // //////#



    // FETCHING MAIN PRODUCT USING URL
    // function getQueryParameter(name) {
    //   const urlParams = new URLSearchParams(window.location.search);
    //   return urlParams.get(name);
    // }
    // function populateProductDetails() {
    //   const productId = getQueryParameter("id");
    //   console.log(productId);
    //   const productName = getQueryParameter("name");
    //   const productDescription = getQueryParameter("description");
    //   const productPrice = getQueryParameter("price");
    //   console.log(productId, productName, productDescription, productPrice);
    //   const productRight = document.querySelector(".product-right");
    //   if (productRight) {
    //     productRight.dataset.index = productId;
    //   }

    //   document.querySelector(".prices .price").innerHTML = productPrice;
    //   document.querySelector(".description .des").innerHTML =
    //     productDescription;
    //   document.querySelector(".product-right #tag").innerHTML = productName;

    //   mainImg.src = `./images/product${productId}.webp`;
    // }
    // populateProductDetails();
  </script>
</body>

</html>